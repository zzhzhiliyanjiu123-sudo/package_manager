# 接入、调度与维护

## API

除健康检查和独立鉴权的 Webhook 外，接口使用 Authorization: Bearer <API_KEY>。网页会话的修改操作使用 X-CSRF-Token。

| 接口 | 方法 | 用途 |
| --- | --- | --- |
| /healthz | GET | 仅检查 Web 与数据库，不代表邮件或调度器健康 |
| /api/parcels | GET | q、state=pending/sent/excluded、page，每页 50 条 |
| /api/parcels | POST | 单条记录或 items 数组 |
| /api/parcels/{id} | PATCH | state 为 excluded 或 pending，已发送单号不可修改 |
| /api/import | POST | multipart 文件，字段名 file |
| /api/template.csv | GET | CSV 模板 |
| /api/settings | GET / PUT | 读取/更新每周设置 |
| /api/send | POST | 将未发送单号快照加入发送队列 |
| /api/deliveries | GET | 最近 30 个发送任务 |
| /api/deliveries/{id}/cancel | POST | 取消等待发送或等待重试的任务 |
| /api/webhooks/{source} | POST | 用对应来源的 X-Webhook-Token 单独鉴权 |

定时设置请求：

```json
{"enabled":true,"weekday":0,"hour":9,"minute":0,"timezone":"Asia/Shanghai"}
```

星期一为 0，星期日为 6；enabled 必须是布尔值。

## 授权转发器

这是供你控制的数据转发器使用的通用接口，不能直接代替购物平台的官方 API 或授权。具体平台签名需由对应转发器验证。

例如，授权数据源给出：

```json
{"data":{"orders":[{"id":"ORDER001","logistics":{"number":"SF1234567890","carrier":"顺丰"}}]}}
```

生成至少 24 位随机 token：

```bash
python3 -c "import secrets; print(secrets.token_urlsafe(32))"
```

.env 中设置一行 JSON，替换示例 token：

```dotenv
PLATFORM_WEBHOOKS_JSON='{"my-forwarder":{"label":"抖音","token":"REPLACE_WITH_A_RANDOM_TOKEN_AT_LEAST_24_CHARS","records_path":"data.orders","tracking_field":"logistics.number","carrier_field":"logistics.carrier","order_field":"id"}}'
```

重建服务后，转发器向 /api/webhooks/my-forwarder POST 数据，携带 X-Webhook-Token。可以配置多个来源，每个使用独立密钥。字段路径支持点号访问对象，不支持数组下标；根对象或数组可省略 records_path。

## 调度规则

- 开关只控制每周新建任务。关闭后继续接收单号，不撤回已入队邮件；可单独取消等待中的任务。
- 保存计划会从现在重新计算下次执行。调度器每 10 秒检查一次。
- 停机错过计划后，恢复时补发一次，然后进入下个未来周次，不为每个错过的周次分别发送。
- 发送保存单号快照；处理中新增单号留待下次。没有新单号不发空邮件。
- 失败最多尝试 5 次，重试间隔为 2、4、8、16 分钟。失败不标记单号已发送。达到上限后检查配置，再点击立即发送。
- 进程中断后，30 分钟租约到期可恢复。SMTP 无法保证恰好一次：邮件已接受、程序尚未记账就中断时，可能重复投递。重试复用 Message-ID，服务商是否去重取决于对方。
- 已发送仅代表 SMTP 接受，不保证进入收件箱，请核对垃圾邮件和发件记录。
- 只启动 Web 不会发送邮件，必须同时运行 scheduler 服务。
- 适合个人使用，没有多用户系统。SQLite 应放本机磁盘，不支持 NFS 或多服务器共享。

## 备份

运行一致性在线备份并复制到主机：

```bash
docker compose exec -T web python -c "import sqlite3; s=sqlite3.connect('/data/parcels.db'); d=sqlite3.connect('/data/backup.db'); s.backup(d); d.close(); s.close()"
docker compose cp web:/data/backup.db ./parcel-backup.db
```

同时安全备份 .env。恢复前停止两个服务，将备份替换数据卷中的数据库，确保没有旧 WAL/SHM 文件；建议先在独立环境验证。

## 不使用 Docker

Linux 需要 Python 3.11+。创建虚拟环境，安装 requirements.txt，运行 configure.py，编辑 .env 后，在当前 shell 加载自己创建和信任的配置：

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python3 configure.py
# 编辑 .env 后：
set -a
. ./.env
set +a
gunicorn --bind 127.0.0.1:8000 --workers 2 --threads 4 wsgi:app
```

另一个终端加载相同环境与配置，在项目目录运行 python -m parcel_digest.worker。生产环境将两个进程分别交给 systemd 等服务管理器守护。


## 订单邮件读取接口

详情见 MAILBOX.md。收信开关独立于每周发送开关，实际收信由 scheduler 服务内独立线程执行。

| 接口 | 方法 | 用途 |
| --- | --- | --- |
| /api/mailbox | GET | 配置状态、检查时间、读取游标及上次统计，不返回密码 |
| /api/mailbox | PUT | 设置 enabled 布尔值与 interval_minutes 整数，范围 1–1440 |
| /api/mailbox/check | POST | 请求立即检查，即使自动收信开关关闭也可使用 |
| /api/orders | GET | 订单和关联包裹，page 分页，每页 50 条 |
| /api/orders/import | POST | 导入授权来源订单，用于后续集成 |

订单导入请求：

```json
{"items":[{"platform":"京东","order_id":"ORDER001","title":"图书","status":"已发货","shipments":[{"tracking_number":"JD1234567890","carrier":"京东物流"}]}]}
```

每次 1–1000 条订单，每个订单最多 20 个包裹。shipments 可为空保存待发货订单，后续以相同平台和订单号更新；快递单号与既有收件箱统一去重，已发送记录不会重置。


## 物流查询

物流缓存和设置接口、服务配置及网关协议见 [TRACKING.md](TRACKING.md)。物流自动更新、IMAP 收信和每周邮件开关互相独立；查询任务由 scheduler 的独立线程执行。


## 包裹分类与取件信息

GET /api/parcels 支持 group 分类筛选，支持取件码与地址搜索。取件信息接口与通知/网关字段见 [PICKUP.md](PICKUP.md)。

"""Generate local deployment credentials; never print secrets to the console."""
import os
import secrets
from pathlib import Path

root = Path(__file__).resolve().parent
template = (root / ".env.example").read_text(encoding="utf-8")
for field in ("ADMIN_PASSWORD", "API_KEY", "SECRET_KEY"):
    template = template.replace("GENERATE_" + field, secrets.token_urlsafe(36))
template = template.replace("INSTANCE_ID=personal", "INSTANCE_ID=" + secrets.token_hex(8))
target = root / ".env"
# O_EXCL makes it impossible to accidentally overwrite existing credentials.
fd = os.open(target, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as file:
    file.write(template)
print("已创建 .env 并生成随机密码和密钥。请在本机编辑邮件配置；请勿分享该文件。")

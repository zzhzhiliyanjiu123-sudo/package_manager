# 快递收件箱 Parcel Digest

Linux 可部署的个人快递单号收集程序。支持网页登录、手动添加、UTF-8 CSV 导入、API 实时推送、授权转发 Webhook、单号去重、每周邮件汇总、定时开关、失败重试以及可配置的物流状态与轨迹显示。

支持淘宝/天猫、京东、拼多多、小红书、抖音、闲鱼、转转等平台标签。**通过订单邮件读取单号，不会直接登录个人购物账号**，平台导出的文件需转换为项目 CSV 模板。真正的平台自动同步仍需对应 API 和授权。新版支持对接物流查询服务，在网站显示状态和轨迹；未配置服务时不查询。

新版增加“自动读取订单邮件”和“识别的订单”前端区域。请参阅 MAILBOX.md 配置收信邮箱。已有部署无需重建数据库，只需补充 IMAP 环境变量并重新构建容器。

物流功能的配置与更新规则见 [物流查询说明](TRACKING.md)。默认未配置服务、关闭自动更新；可先使用前端，之后配置快递100或自有 HTTPS 查询网关。

新版还支持 [待取件与运输中分类](PICKUP.md)：显示取件码和取件地址，支持通知邮件自动提取、手动补充和标记已取件。普通已签收不会直接归为待取件。

## Linux 部署

安装 Docker Engine、Compose v2、Python 3，将整个项目上传到服务器后：

```bash
cd /opt/parcel-digest
python3 configure.py
nano .env
```

脚本生成随机管理密码和密钥，不覆盖已有配置。登录密码是 .env 的 ADMIN_PASSWORD。编辑邮件设置，例如 QQ 邮箱：

```dotenv
SMTP_HOST=smtp.qq.com
SMTP_PORT=465
SMTP_SECURITY=ssl
SMTP_USER=your-account@qq.com
SMTP_PASSWORD=your-smtp-authorization-code
SMTP_FROM=your-account@qq.com
MAIL_TO=your-recipient@example.com
```

使用 SMTP 授权码；其他服务的 587 端口一般用 starttls。特殊字符的值可用单引号包围。请保护 .env，不提交到 Git。本版配置一个收件地址。

```bash
docker compose up -d --build
docker compose ps
docker compose logs --tail=50 web scheduler
```

默认仅监听服务器 127.0.0.1:8000。在自己电脑运行：

```bash
ssh -L 8000:127.0.0.1:8000 your-user@your-server
```

访问 http://127.0.0.1:8000，输入管理密码。添加真实单号，点击立即发送，收到邮件后开启定时。默认星期一北京时间 09:00，首次安装关闭定时。

外部推送或手机直接访问需配置 HTTPS 域名及 Caddy/Nginx 反向代理到 127.0.0.1:8000，并设置 COOKIE_SECURE=true。修改 .env 后运行 docker compose up -d --force-recreate。

数据库保存在 parcel_data 命名卷中，正常停止不会丢失；docker compose down -v 会删除数据。

## API 和 CSV

API 使用 Authorization: Bearer <API_KEY>，API_KEY 来自 .env。

POST /api/parcels 请求示例：

```json
{"tracking_number":"SF1234567890","carrier":"顺丰","platform":"小红书","order_id":"ORDER001","note":"外套"}
```

批量格式为 {"items":[记录1,记录2]}。每次 1–1000 条，最多 2 MB。单号是 5–80 位字母、数字或连字符的字符串；保留前导零，统一大写去重，重复提交不覆盖旧记录。非法记录导致整批不写入。

CSV 需 UTF-8，表头为 tracking_number,carrier,platform,order_id,note。网页可下载模板，examples/parcels.csv 提供示例。examples/forward.py 展示授权数据的推送，不会抓取订单。

自动收信配置见 [订单邮件读取说明](MAILBOX.md)，详细接口见 INTEGRATION.md。

## 验证与限制

python -m unittest discover -s tests -v

99 项测试覆盖鉴权、CSRF、导入去重、Webhook、时区、开关、重试、订单合并、邮件解析、IMAP 游标、物流轨迹适配、查询缓存、签收停止更新和并发认领，使用模拟发送器。交付环境没有 Docker 和邮箱配置，尚未构建 Linux 镜像或真实投递；浏览器视觉检查也未完成。部署后请确认实际邮件投递。

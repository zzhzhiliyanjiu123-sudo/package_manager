import tempfile
import unittest
from datetime import timedelta
from email.message import EmailMessage
from pathlib import Path
from parcel_digest import core, mailbox, pickup, tracking
from parcel_digest.web import create_app

class PickupTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=str(Path(self.temp.name)/'test.db')
        self.cfg={'DATABASE_PATH':self.path,'ADMIN_PASSWORD':'test-password-strong','SECRET_KEY':'s'*40,'API_KEY':'k'*40,
                  'TRACKING_PROVIDER':'gateway','TRACKING_GATEWAY_URL':'https://gateway.example.test/query','TRACKING_GATEWAY_TOKEN':'secret'}
        self.app=create_app(self.cfg)
        self.app.testing=True
        self.client=self.app.test_client()
        self.auth={'Authorization':'Bearer '+'k'*40}
        core.add_parcels(self.path,[{'tracking_number':'SF1234567890','carrier':'顺丰'}])
        self.now=core.now_utc()+timedelta(seconds=2)
    def tearDown(self): self.temp.cleanup()
    def get(self,query=''):
        response=self.client.get('/api/parcels'+query,headers=self.auth)
        self.assertEqual(response.status_code,200)
        return response.json
    def set_tracking(self,status,events=None):
        tracking.detail(self.path,1,self.cfg)
        with core.database(self.path) as con:
            con.execute('UPDATE parcel_tracking SET status=?,events_json=? WHERE parcel_id=1',(status,tracking.json.dumps(events or [])))
    def test_manual_ready_groups_code_and_address(self):
        response=self.client.put('/api/parcels/1/pickup',headers=self.auth,json={'pickup_state':'ready','pickup_code':'3-1024','pickup_address':'东门菜鸟驿站'})
        self.assertEqual(response.status_code,200)
        result=self.get('?group=pickup')
        self.assertEqual(result['total'],1)
        self.assertEqual(result['group_counts']['pickup'],1)
        self.assertEqual(result['items'][0]['pickup_code'],'3-1024')
        self.assertEqual(result['items'][0]['pickup_address'],'东门菜鸟驿站')
        self.assertTrue(result['items'][0]['arrived_at'])
    def test_transit_latest_event_and_group_counts_before_pagination(self):
        self.set_tracking('in_transit',[{'time':'2026-10-20 10:00','description':'到达上海转运中心','location':'上海'}])
        result=self.get('?group=transit')
        self.assertEqual(result['items'][0]['logistics_latest']['description'],'到达上海转运中心')
        self.assertEqual(self.get('?group=pickup')['group_counts']['transit'],1)
    def test_delivered_is_not_automatically_pickup(self):
        self.set_tracking('delivered')
        self.assertEqual(self.get('?group=pickup')['total'],0)
        self.assertEqual(self.get('?group=completed')['total'],1)
    def test_delivered_at_station_with_explicit_pickup_notice_is_ready(self):
        self.set_tracking('delivered')
        pickup.automatic(self.path,'SF1234567890',{'pickup_state':'ready','pickup_code':'1234','pickup_address':'小区驿站'},'email')
        self.assertEqual(self.get('?group=pickup')['total'],1)
    def test_missing_code_keeps_arrived_package_in_pickup_group(self):
        pickup.update(self.path,1,{'pickup_state':'ready','pickup_code':'','pickup_address':'东门驿站'})
        self.assertEqual(self.get('?group=pickup')['total'],1)
        self.assertEqual(self.get('?group=pickup')['items'][0]['pickup_code'],'')
    def test_collect_moves_to_completed_without_changing_email_state(self):
        pickup.update(self.path,1,{'pickup_state':'ready','pickup_code':'1024','pickup_address':'驿站'})
        response=self.client.post('/api/parcels/1/pickup/collect',headers=self.auth)
        self.assertEqual(response.status_code,200)
        self.assertTrue(response.json['collected_at'])
        self.assertEqual(self.get('?group=completed')['total'],1)
        self.assertEqual(self.get('?group=pickup')['total'],0)
        self.assertEqual(self.get()['items'][0]['state'],'pending')
    def test_collected_not_reopened_by_old_notification(self):
        pickup.collect(self.path,1)
        pickup.allow_updates(self.path,1)
        pickup.automatic(self.path,'SF1234567890',{'pickup_state':'ready','pickup_code':'9999'},'email')
        self.assertEqual(pickup.detail(self.path,1)['pickup_state'],'collected')
    def test_manual_lock_and_restore_automatic(self):
        pickup.update(self.path,1,{'pickup_state':'ready','pickup_code':'MANUAL','pickup_address':'正确地址'})
        pickup.automatic(self.path,'SF1234567890',{'pickup_state':'ready','pickup_code':'9999','pickup_address':'错误地址'},'email')
        self.assertEqual(pickup.detail(self.path,1)['pickup_code'],'MANUAL')
        pickup.allow_updates(self.path,1)
        pickup.automatic(self.path,'SF1234567890',{'pickup_state':'ready','pickup_code':'8888','pickup_address':''},'email')
        self.assertEqual(pickup.detail(self.path,1)['pickup_code'],'8888')
        self.assertEqual(pickup.detail(self.path,1)['pickup_address'],'正确地址')
    def test_exclusion_and_returned_override_ready_group(self):
        pickup.update(self.path,1,{'pickup_state':'ready','pickup_code':'1024'})
        self.set_tracking('returned')
        self.assertEqual(self.get('?group=completed')['total'],1)
        core.change_state(self.path,1,'excluded')
        self.assertEqual(self.get('?group=excluded')['total'],1)
    def test_search_pickup_code_and_address(self):
        pickup.update(self.path,1,{'pickup_state':'ready','pickup_code':'3-1024','pickup_address':'小区东门'})
        self.assertEqual(self.get('?q=3-1024&group=pickup')['total'],1)
        self.assertEqual(self.get('?q=小区东门&group=pickup')['total'],1)
        self.assertEqual(self.get('?q=不存在')['total'],0)
    def test_pickup_api_requires_auth_and_csrf(self):
        self.assertEqual(self.client.get('/api/parcels/1/pickup').status_code,401)
        self.assertEqual(self.client.post('/api/parcels/1/pickup/collect').status_code,401)
        with self.client.session_transaction() as session:
            session['authenticated']=True
            session['csrf']='csrf-test'
        self.assertEqual(self.client.post('/api/parcels/1/pickup/collect').status_code,403)
    def test_validation_is_atomic(self):
        for bad in ({'pickup_state':'bad'},{'pickup_state':'ready','pickup_code':'x'*33},{'pickup_state':'ready','pickup_address':'bad\naddress'}):
            self.assertEqual(self.client.put('/api/parcels/1/pickup',headers=self.auth,json=bad).status_code,400)
        self.assertEqual(pickup.detail(self.path,1)['pickup_state'],'none')
        self.assertEqual(self.client.get('/api/parcels/999/pickup',headers=self.auth).status_code,400)
    def test_track_latest_notice_promotes_and_persists_code(self):
        tracking.save_parcel(self.path,1,{'carrier_code':'sf','monitored':True})
        tracking.request_refresh(self.path,1,self.cfg)
        query=lambda *_:{'status':'delivered','events':[{'time':'2026-10-20 10:00','description':'已到达菜鸟驿站，取件码：3-1024，取件地址：小区东门驿站。','location':'上海'}]}
        self.assertEqual(tracking.sync_tick(self.path,self.cfg,query,now=self.now),'updated')
        item=self.get('?group=pickup')['items'][0]
        self.assertEqual(item['pickup_code'],'3-1024')
        self.assertEqual(item['pickup_address'],'小区东门驿站')
        self.assertEqual(item['logistics_status'],'ready_for_pickup')
    def test_old_history_notice_does_not_reopen_latest_collected(self):
        payload={'tracking_number':'SF1234567890','status':'delivered','events':[
            {'time':'2026-10-20 10:00','description':'用户已取件'},
            {'time':'2026-10-19 10:00','description':'待取件，取件码：3-1024'}]}
        result=tracking.normalize_response(payload,'SF1234567890')
        self.assertEqual(result['status'],'picked_up')
        self.assertEqual(result['pickup']['pickup_state'],'collected')
    def test_gateway_explicit_pickup_fields(self):
        result=tracking.normalize_response({'tracking_number':'SF1234567890','status':'ready_for_pickup','events':[],
            'pickup':{'pickup_code':'123456','pickup_address':'快递柜A'}},'SF1234567890')
        self.assertEqual(result['pickup']['pickup_state'],'ready')
        self.assertEqual(result['pickup']['pickup_address'],'快递柜A')
    def test_collected_stops_auto_tracking(self):
        pickup.collect(self.path,1)
        tracking.save_settings(self.path,True,30)
        self.assertEqual(tracking.sync_tick(self.path,self.cfg,lambda *_:self.fail('Unexpected query'),now=self.now),'idle')
    def test_manual_correction_clears_false_pickup_classification(self):
        self.set_tracking('ready_for_pickup')
        self.assertEqual(self.get('?group=pickup')['total'],1)
        pickup.update(self.path,1,{'pickup_state':'none','pickup_code':'','pickup_address':''})
        self.assertEqual(self.get('?group=pickup')['total'],0)
        self.assertEqual(self.get('?group=other')['total'],1)

    def test_idempotent_schema_initialization_preserves_pickup(self):
        pickup.update(self.path,1,{'pickup_state':'ready','pickup_code':'3-1024'})
        pickup.init_pickup(self.path)
        create_app(self.cfg)
        self.assertEqual(pickup.detail(self.path,1)['pickup_code'],'3-1024')

class NoticeExtractionTests(unittest.TestCase):
    def message(self,body,html=False):
        msg=EmailMessage()
        msg['Subject']='取件通知'
        msg['From']='notify@example.test'
        msg['To']='owner@example.test'
        msg.set_content('' if html else body)
        if html: msg.add_alternative(body,subtype='html')
        return mailbox.extract(msg.as_bytes())
    def test_plain_and_html_pickup_notices(self):
        for body,html in (('运单号：SF1234567890\n取件码：3-1024\n取件地址：小区东门驿站。',False),
                          ('<p>运单号：SF1234567890</p><p>取件码：3-1024</p><p>取件地址：小区东门驿站。</p>',True)):
            result=self.message(body,html)
            self.assertEqual(result['pickup']['pickup_code'],'3-1024')
            self.assertEqual(result['pickup']['pickup_address'],'小区东门驿站')
    def test_multiple_parcels_do_not_share_single_pickup_code(self):
        result=self.message('运单号：SF1234567890 运单号：YT1234567890 取件码：3-1024 取件地址：东门驿站。')
        self.assertNotIn('pickup',result)
    def test_multiple_codes_are_not_guessed(self):
        notice=pickup.extract_notice('取件码：3-1024；取件码：8-2048。')
        self.assertEqual(notice['pickup_code'],'')
    def test_order_id_or_phone_is_not_a_pickup_code(self):
        notice=pickup.extract_notice('订单号：ORDER12345，联系电话：13800138000。')
        self.assertEqual(notice['pickup_state'],'')
        self.assertEqual(notice['pickup_code'],'')
    def test_address_stops_at_next_label(self):
        notice=pickup.extract_notice('取件地址：小区东门驿站，取件码：3-1024，运单号：SF1234567890')
        self.assertEqual(notice['pickup_address'],'小区东门驿站')
    def test_station_arrival_without_code_is_ready(self):
        notice=pickup.extract_notice('您的包裹已放入快递柜，请及时取件。')
        self.assertEqual(notice['pickup_state'],'ready')
        self.assertEqual(notice['pickup_code'],'')

if __name__=='__main__': unittest.main()

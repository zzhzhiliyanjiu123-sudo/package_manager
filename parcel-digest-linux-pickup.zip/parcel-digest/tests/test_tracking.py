import hashlib
import json
import ssl
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from pathlib import Path
from urllib.parse import parse_qs
from unittest.mock import Mock, patch
from parcel_digest import core, tracking
from parcel_digest.web import create_app

EVENT={'time':'2026-10-20 10:00:00','description':'快件正在运输途中','location':'上海'}

class ProviderTests(unittest.TestCase):
    def setUp(self):
        self.parcel={'tracking_number':'SF1234567890','carrier':'顺丰','carrier_code':'','phone_last4':'1234'}
        self.cfg={'TRACKING_PROVIDER':'kuaidi100','KUAIDI100_KEY':'test-key','KUAIDI100_CUSTOMER':'customer'}
    def test_kuaidi100_signature_and_normalization(self):
        transport=Mock(return_value={'status':'200','nu':'SF1234567890','state':'5','data':[{'time':'2026-10-20 10:00:00','context':'派送中'}]})
        result=tracking.query_provider(self.parcel,self.cfg,transport)
        self.assertEqual(result['status'],'out_for_delivery')
        url,body,headers=transport.call_args.args
        self.assertEqual(url,'https://poll.kuaidi100.com/poll/query.do')
        fields=parse_qs(body.decode())
        expected=hashlib.md5((fields['param'][0]+'test-key'+'customer').encode()).hexdigest().upper()
        self.assertEqual(fields['sign'][0],expected)
        params=json.loads(fields['param'][0])
        self.assertEqual(params['com'],'shunfeng')
        self.assertEqual(params['phone'],'1234')
        self.assertEqual(params['order'],'desc')
    def test_native_delivered_and_error_without_exposing_server_message(self):
        result=tracking.query_provider(self.parcel,self.cfg,lambda *_:{'status':'200','nu':'SF1234567890','state':'3','data':[]})
        self.assertEqual(result['status'],'delivered')
        with self.assertRaises(tracking.TrackingError) as captured:
            tracking.query_provider(self.parcel,self.cfg,lambda *_:{'status':'400','message':'PRIVATE API KEY'})
        self.assertNotIn('PRIVATE',str(captured.exception))
    def test_gateway_contract_and_authorization(self):
        cfg={'TRACKING_PROVIDER':'gateway','TRACKING_GATEWAY_URL':'https://gateway.example.test/query','TRACKING_GATEWAY_TOKEN':'secret'}
        parcel={**self.parcel,'carrier_code':'sf'}
        transport=Mock(return_value={'tracking_number':parcel['tracking_number'],'status':'in_transit','events':[EVENT]})
        self.assertEqual(tracking.query_provider(parcel,cfg,transport)['events'],[EVENT])
        self.assertEqual(transport.call_args.args[2]['Authorization'],'Bearer secret')
        self.assertEqual(json.loads(transport.call_args.args[1])['carrier_code'],'sf')
    def test_mismatched_number_and_invalid_events_rejected(self):
        for payload in ({'tracking_number':'OTHER123','status':'delivered','events':[]},
                        {'tracking_number':123,'status':'delivered','events':[]},
                        {'tracking_number':'SF1234567890','status':[],'events':[]},
                        {'tracking_number':'SF1234567890','status':'in_transit','events':[{'time':'','description':'x'}]}):
            with self.assertRaises(tracking.TrackingError): tracking.normalize_response(payload,'SF1234567890')
    def test_duplicate_events_collapsed_and_order_preserved(self):
        result=tracking.normalize_response({'tracking_number':'SF1234567890','status':'in_transit','events':[EVENT,EVENT]},'SF1234567890')
        self.assertEqual(result['events'],[EVENT])
    def test_transport_rejects_insecure_urls_before_network(self):
        for url in ('http://gateway.test/query','https://user:pass@gateway.test/query','https://gateway.test/query#fragment'):
            with self.assertRaises(tracking.TrackingError): tracking.post_json(url,b'{}')
    def test_redirect_is_not_followed_with_credentials(self):
        with self.assertRaises(tracking.TrackingError): tracking.NoRedirect().redirect_request(None,None,302,'redirect',{},'https://other.test')
    def test_unrecognized_carrier_requires_configuration(self):
        with self.assertRaises(tracking.TrackingError): tracking.query_provider({**self.parcel,'carrier':'未知快递'},self.cfg,Mock())

class TrackingTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=str(Path(self.temp.name)/'test.db')
        self.cfg={'DATABASE_PATH':self.path,'ADMIN_PASSWORD':'test-password-strong','SECRET_KEY':'s'*40,'API_KEY':'k'*40,'TRACKING_PROVIDER':'kuaidi100','KUAIDI100_CUSTOMER':'customer','KUAIDI100_KEY':'private-key'}
        self.app=create_app(self.cfg)
        self.app.testing=True
        self.client=self.app.test_client()
        self.auth={'Authorization':'Bearer '+'k'*40}
        core.add_parcels(self.path,[{'tracking_number':'SF1234567890','carrier':'顺丰'}])
        self.now=core.now_utc()+timedelta(seconds=2)
        self.query=Mock(return_value={'status':'in_transit','events':[EVENT]})
    def tearDown(self): self.temp.cleanup()
    def tick(self,offset=0): return tracking.sync_tick(self.path,self.cfg,self.query,now=self.now+timedelta(minutes=offset))
    def detail(self): return tracking.detail(self.path,1,self.cfg)
    def test_default_disabled_and_unconfigured_never_queries(self):
        self.assertEqual(self.tick(),'idle')
        self.query.assert_not_called()
        tracking.save_settings(self.path,True,30)
        cfg={**self.cfg,'TRACKING_PROVIDER':'none'}
        self.assertEqual(tracking.sync_tick(self.path,cfg,self.query),'idle')
        self.query.assert_not_called()
    def test_manual_refresh_updates_and_list_has_latest_event(self):
        self.assertEqual(tracking.request_refresh(self.path,1,self.cfg),'queued')
        self.assertEqual(self.tick(),'updated')
        self.assertEqual(self.detail()['events'],[EVENT])
        result=self.client.get('/api/parcels',headers=self.auth).json['items'][0]
        self.assertEqual(result['logistics_label'],'运输中')
        self.assertEqual(result['logistics_latest']['description'],EVENT['description'])
        self.assertEqual(core.settings(self.path)['enabled'],0)
    def test_manual_duplicate_and_rate_limit(self):
        tracking.request_refresh(self.path,1,self.cfg)
        self.assertEqual(tracking.request_refresh(self.path,1,self.cfg),'busy')
        self.tick()
        with self.assertRaises(ValueError): tracking.request_refresh(self.path,1,self.cfg)
    def test_automatic_interval(self):
        tracking.save_settings(self.path,True,30)
        self.assertEqual(self.tick(),'updated')
        self.assertEqual(self.tick(1),'idle')
        self.assertEqual(self.tick(31),'updated')
    def test_delivered_stops_automatic_but_manual_refresh_allowed(self):
        tracking.save_settings(self.path,True,5)
        self.query.return_value={'status':'delivered','events':[EVENT]}
        self.assertEqual(self.tick(),'updated')
        self.assertEqual(self.tick(60),'idle')
        with core.database(self.path) as con:
            con.execute("UPDATE parcel_tracking SET last_attempt='' WHERE parcel_id=1")
        tracking.request_refresh(self.path,1,self.cfg)
        self.assertEqual(self.tick(61),'updated')
    def test_sent_email_does_not_stop_logistics(self):
        with core.database(self.path) as con: con.execute("UPDATE parcels SET state='sent'")
        tracking.save_settings(self.path,True,30)
        self.assertEqual(self.tick(),'updated')
    def test_excluded_and_unmonitored_skipped(self):
        tracking.save_settings(self.path,True,30)
        core.change_state(self.path,1,'excluded')
        self.assertEqual(self.tick(),'idle')
        core.change_state(self.path,1,'pending')
        tracking.save_parcel(self.path,1,{'carrier_code':'shunfeng','monitored':False})
        self.assertEqual(self.tick(),'idle')
    def test_error_preserves_last_good_results_and_backs_off(self):
        tracking.save_settings(self.path,True,5)
        self.tick()
        self.query.side_effect=OSError('PRIVATE-SECRET response')
        self.assertEqual(self.tick(6),'error')
        item=self.detail()
        self.assertEqual(item['events'],[EVENT])
        self.assertEqual(item['status'],'in_transit')
        self.assertTrue(item['stale'])
        self.assertNotIn('PRIVATE',item['error'])
        self.assertEqual(self.tick(7),'idle')
    def test_concurrent_workers_claim_once(self):
        tracking.request_refresh(self.path,1,self.cfg)
        with ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(lambda _:self.tick(),range(4)))
        self.assertEqual(results.count('updated'),1)
        self.assertEqual(self.query.call_count,1)
    def test_expired_lease_recovers_manual_while_auto_disabled(self):
        self.detail()
        with core.database(self.path) as con:
            con.execute('UPDATE parcel_tracking SET lease_until=?,claim_token=? WHERE parcel_id=1',(core.stamp(self.now-timedelta(minutes=1)),'old'))
        self.assertEqual(self.tick(),'updated')
    def test_phone_tail_not_returned_and_can_be_cleared(self):
        tracking.save_parcel(self.path,1,{'carrier_code':'shunfeng','monitored':True,'phone_last4':'1234'})
        item=self.detail()
        self.assertNotIn('phone_last4',item)
        self.assertTrue(item['has_phone_last4'])
        tracking.save_parcel(self.path,1,{'carrier_code':'shunfeng','monitored':True})
        self.assertTrue(self.detail()['has_phone_last4'])
        tracking.save_parcel(self.path,1,{'carrier_code':'shunfeng','monitored':True,'phone_last4':''})
        self.assertFalse(self.detail()['has_phone_last4'])
    def test_carrier_change_clears_old_cache(self):
        tracking.request_refresh(self.path,1,self.cfg)
        self.tick()
        tracking.save_parcel(self.path,1,{'carrier_code':'zhongtong','monitored':True})
        self.assertEqual(self.detail()['events'],[])
        self.assertEqual(self.detail()['status'],'unknown')
    def test_api_auth_csrf_validation_and_no_keys(self):
        self.assertEqual(self.client.get('/api/tracking/settings').status_code,401)
        self.assertEqual(self.client.post('/api/parcels/1/tracking/refresh').status_code,401)
        self.assertNotIn('private-key',self.client.get('/api/tracking/settings',headers=self.auth).text)
        for invalid in ({'enabled':'false','interval_minutes':30},{'enabled':True,'interval_minutes':1}):
            self.assertEqual(self.client.put('/api/tracking/settings',headers=self.auth,json=invalid).status_code,400)
        with self.client.session_transaction() as session:
            session['authenticated']=True
            session['csrf']='test-csrf'
        self.assertEqual(self.client.put('/api/tracking/settings',json={'enabled':True,'interval_minutes':30}).status_code,403)
    def test_missing_carrier_and_invalid_phone(self):
        core.add_parcels(self.path,[{'tracking_number':'XX1234567890','carrier':'其他'}])
        with self.assertRaises(ValueError): tracking.request_refresh(self.path,2,self.cfg)
        for phone in ('123','abcd',1234):
            with self.assertRaises(ValueError): tracking.save_parcel(self.path,1,{'carrier_code':'sf','monitored':True,'phone_last4':phone})
    def test_unconfigured_frontend_settings_and_detail_still_available(self):
        app=create_app({**self.cfg,'TRACKING_PROVIDER':'none'})
        client=app.test_client()
        self.assertFalse(client.get('/api/tracking/settings',headers=self.auth).json['configured'])
        self.assertEqual(client.get('/api/parcels/1/tracking',headers=self.auth).status_code,200)
        self.assertEqual(client.post('/api/parcels/1/tracking/refresh',headers=self.auth).status_code,400)
        self.assertEqual(client.put('/api/tracking/settings',headers=self.auth,json={'enabled':True,'interval_minutes':30}).status_code,400)

if __name__=='__main__': unittest.main()

import tempfile
import unittest
from pathlib import Path

from parcel_digest import core, orders


class OrderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / 'orders.db')
        core.init_db(self.path)
        orders.init_orders(self.path)

    def tearDown(self):
        self.temp.cleanup()

    def snapshot(self, **changes):
        return {'platform': '京东', 'order_id': 'ORDER001', 'title': '图书', 'status': '待发货', **changes}

    def all(self, table):
        with core.database(self.path) as con:
            return [dict(row) for row in con.execute('SELECT * FROM '+table)]

    def test_unshipped_order_then_shipment(self):
        self.assertEqual(orders.ingest_orders(self.path,[self.snapshot()])['parcels_inserted'],0)
        self.assertEqual(len(self.all('orders')),1)
        result=orders.ingest_orders(self.path,[self.snapshot(status='已发货',shipments=[{'tracking_number':'JD123456'}])])
        self.assertEqual(result['parcels_inserted'],1)
        self.assertEqual(self.all('parcels')[0]['note'],'图书')
        self.assertEqual(self.all('orders')[0]['status'],'已发货')

    def test_repeated_snapshot_and_multi_parcel_order(self):
        record=self.snapshot(shipments=[{'tracking_number':'JD123456'},{'tracking_number':'SF123456'}])
        self.assertEqual(orders.ingest_orders(self.path,[record])['parcels_inserted'],2)
        self.assertEqual(orders.ingest_orders(self.path,[record])['parcels_inserted'],0)
        self.assertEqual(len(self.all('order_shipments')),2)

    def test_same_order_id_different_platforms(self):
        orders.ingest_orders(self.path,[self.snapshot(),self.snapshot(platform='淘宝/天猫')])
        self.assertEqual(len(self.all('orders')),2)

    def test_sent_parcel_not_reset_by_order_sync(self):
        record=self.snapshot(shipments=[{'tracking_number':'JD123456'}])
        orders.ingest_orders(self.path,[record])
        with core.database(self.path) as con:
            con.execute("UPDATE parcels SET state='sent'")
        orders.ingest_orders(self.path,[record])
        self.assertEqual(self.all('parcels')[0]['state'],'sent')

    def test_invalid_batch_leaves_no_partial_order(self):
        with self.assertRaises(ValueError):
            orders.ingest_orders(self.path,[self.snapshot(),self.snapshot(order_id='ORDER002',shipments=[{'tracking_number':123}])])
        self.assertEqual(self.all('orders'),[])

    def test_empty_fields_do_not_erase_order_metadata(self):
        orders.ingest_orders(self.path,[self.snapshot()])
        orders.ingest_orders(self.path,[self.snapshot(title='',status='')])
        self.assertEqual(self.all('orders')[0]['title'],'图书')
        self.assertEqual(self.all('orders')[0]['status'],'待发货')


if __name__=='__main__':
    unittest.main()

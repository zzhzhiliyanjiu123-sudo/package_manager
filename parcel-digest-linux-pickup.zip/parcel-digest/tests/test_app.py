import io
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path

from parcel_digest import core
from parcel_digest.web import create_app


class ParcelTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.temp.name) / "test.db")
        self.cfg = {"DATABASE_PATH": self.path, "ADMIN_PASSWORD": "test-password-strong",
                    "SECRET_KEY": "s" * 40, "API_KEY": "k" * 40,
                    "SMTP_HOST": "smtp.example.test", "SMTP_FROM": "sender@example.test",
                    "MAIL_TO": "owner@example.test", "INSTANCE_ID": "tests", "WEBHOOKS": {
                        "authorized": {"token": "w" * 32, "label": "小红书", "records_path": "data.orders",
                                       "tracking_field": "logistics.number", "carrier_field": "logistics.carrier"}}}
        self.app = create_app(self.cfg)
        self.app.testing = True
        self.client = self.app.test_client()
        self.auth = {"Authorization": "Bearer " + self.cfg["API_KEY"]}

    def tearDown(self):
        self.temp.cleanup()

    def add(self, number="SF1234567890", **fields):
        return core.add_parcels(self.path, [{"tracking_number": number, **fields}])

    def rows(self, table):
        with core.database(self.path) as con:
            return [dict(row) for row in con.execute("SELECT * FROM " + table)]

    def tick(self, **kwargs):
        return core.scheduler_tick(self.path, self.cfg, **kwargs)

    def test_auth_required_and_health(self):
        self.assertEqual(self.client.get('/api/parcels').status_code, 401)
        self.assertEqual(self.client.post('/api/parcels', json={}).status_code, 401)
        self.assertEqual(self.client.get('/healthz').status_code, 200)
        self.assertEqual(self.client.get('/').status_code, 302)

    def test_login_csrf_and_dashboard(self):
        self.client.get('/login')
        with self.client.session_transaction() as session:
            csrf = session['login_csrf']
        self.assertEqual(self.client.post('/login', data={'password': self.cfg['ADMIN_PASSWORD']}).status_code, 403)
        self.assertEqual(self.client.post('/login', data={'password': self.cfg['ADMIN_PASSWORD'], 'csrf': csrf}).status_code, 302)
        self.assertEqual(self.client.get('/').status_code, 200)
        self.assertEqual(self.client.post('/api/parcels', json={'tracking_number': 'SF12345'}).status_code, 403)
        with self.client.session_transaction() as session:
            csrf = session['csrf']
        self.assertEqual(self.client.post('/api/parcels', json={'tracking_number': 'SF12345'}, headers={'X-CSRF-Token':csrf}).status_code, 201)

    def test_unicode_password_does_not_crash(self):
        self.client.get('/login')
        with self.client.session_transaction() as session:
            csrf=session['login_csrf']
        self.assertEqual(self.client.post('/login',data={'password':'中文错误密码','csrf':csrf}).status_code,401)

    def test_case_insensitive_dedup_does_not_overwrite(self):
        self.add('sf12345', note='first')
        result=self.add('SF12345',note='second')
        self.assertEqual(result, {'inserted':0,'duplicates':1})
        self.assertEqual(self.rows('parcels')[0]['note'],'first')

    def test_batch_validation_is_atomic(self):
        with self.assertRaises(ValueError):
            core.add_parcels(self.path,[{'tracking_number':'SF12345'},{'tracking_number':12345}])
        self.assertEqual(self.rows('parcels'),[])

    def test_csv_unicode_and_leading_zero(self):
        raw='\ufefftracking_number,platform,note\r\n0012345678,闲鱼,二手书\r\n'.encode('utf-8')
        response=self.client.post('/api/import',headers=self.auth,data={'file':(io.BytesIO(raw),'test.csv')})
        self.assertEqual(response.status_code,200)
        row=self.rows('parcels')[0]
        self.assertEqual(row['tracking_number'],'0012345678')
        self.assertEqual(row['platform'],'闲鱼')

    def test_csv_missing_header_and_overflow(self):
        for raw in (b'number\n12345',b'tracking_number\nSF12345,extra'):
            with self.assertRaises(ValueError):core.parse_csv(raw)

    def test_api_search_and_malformed_payload(self):
        self.add(platform='抖音')
        response=self.client.get('/api/parcels?q=抖音',headers=self.auth)
        self.assertEqual(response.json['total'],1)
        self.assertEqual(self.client.post('/api/parcels',headers=self.auth,json=[]).status_code,400)
        self.assertEqual(self.client.post('/api/parcels',headers=self.auth,json={'items':[]}).status_code,400)

    def test_webhook_auth_and_nested_mapping(self):
        payload={'data':{'orders':[{'logistics':{'number':'YT12345','carrier':'圆通'}}]}}
        self.assertEqual(self.client.post('/api/webhooks/authorized',json=payload).status_code,401)
        response=self.client.post('/api/webhooks/authorized',json=payload,headers={'X-Webhook-Token':'w'*32})
        self.assertEqual(response.status_code,201)
        self.assertEqual(self.rows('parcels')[0]['platform'],'小红书')

    def test_next_run_beijing_and_exact_boundary(self):
        now=datetime(2026,10,19,0,0,tzinfo=timezone.utc)
        self.assertEqual(core.next_run(now,0,9,0,'Asia/Shanghai'),'2026-10-19T01:00:00+00:00')
        self.assertEqual(core.next_run(now+timedelta(hours=1),0,9,0,'Asia/Shanghai'),'2026-10-26T01:00:00+00:00')

    def test_dst_nonexistent_time_skipped(self):
        now=datetime(2026,3,7,12,tzinfo=timezone.utc)
        self.assertEqual(core.next_run(now,6,2,30,'America/New_York'),'2026-03-15T06:30:00+00:00')

    def test_disabled_does_not_send(self):
        self.add()
        self.assertEqual(self.tick(send=lambda *_:self.fail('unexpected send')),'idle')
        self.assertEqual(self.rows('parcels')[0]['state'],'pending')

    def test_due_weekly_only_once_and_restart_persistence(self):
        self.add()
        instant=core.now_utc()
        with core.database(self.path) as con:
            con.execute('UPDATE settings SET enabled=1,next_run=?',(core.stamp(instant-timedelta(minutes=1)),))
        sent=[]
        self.assertEqual(self.tick(send=lambda msg,_:sent.append(msg),now=instant),'sent')
        core.init_db(self.path)
        self.assertEqual(self.tick(send=lambda msg,_:sent.append(msg),now=instant),'idle')
        self.assertEqual(len(sent),1)
        self.assertEqual(self.rows('parcels')[0]['state'],'sent')

    def test_manual_snapshot_exclusion_and_no_empty_email(self):
        self.assertEqual(core.request_delivery(self.path),'empty')
        self.add('SF12345')
        self.add('SF67890')
        core.change_state(self.path,2,'excluded')
        self.assertEqual(core.request_delivery(self.path),'queued')
        self.add('SF99999')
        sent=[]
        self.tick(send=lambda msg,_:sent.append(msg))
        self.assertIn('SF12345',sent[0].get_body(preferencelist=('plain',)).get_content())
        self.assertNotIn('SF99999',sent[0].get_body(preferencelist=('plain',)).get_content())
        self.assertEqual([r['state'] for r in self.rows('parcels')],['sent','excluded','pending'])

    def test_queue_lock_and_cancellation(self):
        self.add()
        core.request_delivery(self.path)
        with self.assertRaises(ValueError):core.change_state(self.path,1,'excluded')
        self.assertEqual(core.request_delivery(self.path),'busy')
        self.assertEqual(self.client.post('/api/deliveries/1/cancel',headers=self.auth).status_code,200)
        core.change_state(self.path,1,'excluded')
        self.assertEqual(self.rows('parcels')[0]['state'],'excluded')

    def test_retry_then_success_preserves_id_and_data(self):
        self.add()
        core.request_delivery(self.path)
        instant=core.now_utc()
        messages=[]
        def fail(msg,_):
            messages.append(msg)
            raise OSError('test failure PRIVATESECRET')
        self.assertEqual(self.tick(send=fail,now=instant),'retry')
        self.assertEqual(self.rows('parcels')[0]['state'],'pending')
        self.assertNotIn('PRIVATESECRET',self.rows('deliveries')[0]['last_error'])
        self.assertEqual(self.tick(send=fail,now=instant),'idle')
        self.assertEqual(self.tick(send=lambda msg,_:messages.append(msg),now=instant+timedelta(minutes=3)),'sent')
        self.assertEqual(messages[0]['Message-ID'],messages[1]['Message-ID'])

    def test_retry_limit_can_be_requeued(self):
        self.add()
        core.request_delivery(self.path)
        instant=core.now_utc()
        def fail(*_):raise OSError('unreachable')
        for attempt in range(5):
            self.tick(send=fail,now=instant+timedelta(hours=attempt))
        self.assertEqual(self.rows('deliveries')[0]['status'],'failed')
        self.assertEqual(self.rows('parcels')[0]['state'],'pending')
        self.assertEqual(core.request_delivery(self.path),'queued')

    def test_concurrent_schedulers_claim_once(self):
        self.add()
        core.request_delivery(self.path)
        sent=[]
        with ThreadPoolExecutor(max_workers=4) as pool:
            results=list(pool.map(lambda _:self.tick(send=lambda msg,_:sent.append(msg)),range(4)))
        self.assertEqual(results.count('sent'),1)
        self.assertEqual(len(sent),1)

    def test_expired_lease_recovers(self):
        self.add()
        core.request_delivery(self.path)
        with core.database(self.path) as con:
            con.execute("UPDATE deliveries SET status='sending',attempts=1,lease_until=?",(core.stamp(core.now_utc()-timedelta(minutes=1)),))
        self.assertEqual(self.tick(send=lambda *_:None),'sent')

    def test_settings_validation_and_switch(self):
        data={'enabled':True,'weekday':6,'hour':20,'minute':30,'timezone':'Asia/Shanghai'}
        self.assertEqual(self.client.put('/api/settings',headers=self.auth,json=data).status_code,200)
        self.assertEqual(core.settings(self.path)['enabled'],1)
        for bad in ({'hour':24},{'enabled':'false'},{'timezone':'bad/zone'},{'weekday':True}):
            self.assertEqual(self.client.put('/api/settings',headers=self.auth,json={**data,**bad}).status_code,400)

    def test_attachment_csv_formula_protection(self):
        self.add(note='=HYPERLINK("https://example.test")')
        msg=core.build_message(1,self.rows('parcels'),self.cfg,self.cfg['MAIL_TO'])
        attachment=next(msg.iter_attachments()).get_payload(decode=True).decode('utf-8-sig')
        self.assertIn("'=HYPERLINK",attachment)


if __name__ == '__main__':
    unittest.main()

import io
import ssl
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from email.message import EmailMessage
from pathlib import Path
from unittest.mock import Mock
from parcel_digest import core, mailbox, orders
from parcel_digest.web import create_app


def message(body='订单号：ORDER12345\n快递公司：顺丰\n运单号：SF1234567890', subject='小红书发货通知', sender='notify@example.test', html=None):
    msg=EmailMessage()
    msg['From']=sender
    msg['To']='owner@example.test'
    msg['Subject']=subject
    msg.set_content(body)
    if html: msg.add_alternative(html,subtype='html')
    return msg


class FakeIMAP:
    def __init__(self):
        self.messages={1:message().as_bytes()}
        self.validity=b'123'
        self.calls=[]
        self.size_override={}
        self.broken=None
        self.logged_out=False
    def login(self,user,password):
        self.calls.append(('login',user))
        return 'OK',[b'logged in']
    def select(self,folder,readonly=False):
        self.calls.append(('select',folder,readonly))
        return 'OK',[str(len(self.messages)).encode()]
    def response(self,code): return code,[self.validity]
    def uid(self,command,*args):
        self.calls.append((command,*args))
        if command=='search':
            # Some IMAP servers return the last old UID for a reversed x:* range.
            return 'OK',[b' '.join(str(uid).encode() for uid in sorted(self.messages))]
        uid=int(args[0])
        if self.broken == uid: raise OSError('private auth or server detail')
        raw=self.messages[uid]
        if args[1]=='(RFC822.SIZE)':
            return 'OK',[f'1 (UID {uid} RFC822.SIZE {self.size_override.get(uid,len(raw))})'.encode()]
        return 'OK',[(b'BODY[]',raw),b')']
    def logout(self):
        self.logged_out=True
        return 'BYE',[b'bye']


class ExtractTests(unittest.TestCase):
    def test_plain_order_and_tracking_are_distinct(self):
        result=mailbox.extract(message().as_bytes())
        self.assertEqual(result['order_id'],'ORDER12345')
        self.assertEqual(result['shipments'][0]['tracking_number'],'SF1234567890')
        self.assertEqual(result['platform'],'小红书')
        self.assertEqual(result['shipments'][0]['carrier'],'顺丰')
    def test_plain_order_number_is_not_a_tracking_number(self):
        self.assertIsNone(mailbox.extract(message('订单号：123456789012，已付款。').as_bytes()))
    def test_html_entities_and_duplicates(self):
        msg=message(html='<p>物流单号&nbsp;:&nbsp;<b>SF1234567890</b></p>')
        self.assertEqual(len(mailbox.extract(msg.as_bytes())['shipments']),1)
    def test_script_and_attachments_are_ignored(self):
        msg=message('暂无单号',html='<script>物流单号: SF99999999</script><p>等待发货</p>')
        msg.add_attachment('物流单号: SF88888888'.encode(),maintype='text',subtype='plain',filename='order.txt')
        self.assertIsNone(mailbox.extract(msg.as_bytes()))
    def test_english_and_leading_zero(self):
        result=mailbox.extract(message('Tracking number: 00123456789','JD.com order shipped').as_bytes())
        self.assertEqual(result['shipments'][0]['tracking_number'],'00123456789')
        self.assertEqual(result['platform'],'京东')
    def test_placeholder_without_digits_is_not_a_number(self):
        self.assertIsNone(mailbox.extract(message('Tracking number: PENDING').as_bytes()))
    def test_sender_filter_exact_domain_and_address(self):
        raw=message().as_bytes()
        self.assertIsNotNone(mailbox.extract(raw,'example.test'))
        self.assertIsNotNone(mailbox.extract(raw,'notify@example.test'))
        self.assertIsNone(mailbox.extract(raw,'other@example.test'))
        self.assertIsNone(mailbox.extract(message(sender='x@evil-example.test').as_bytes(),'example.test'))
    def test_multiple_orders_do_not_get_wrongly_associated(self):
        result=mailbox.extract(message('订单号: ORDER11111 订单号: ORDER22222 物流单号: SF1234567890').as_bytes())
        self.assertEqual(result['order_id'],'')
    def test_folder_quoting_and_modified_utf7(self):
        self.assertEqual(mailbox.folder_argument('INBOX'),'"INBOX"')
        self.assertEqual(mailbox.folder_argument('Order Mail'),'"Order Mail"')
        self.assertEqual(mailbox.folder_argument('A&B'),'"A&-B"')
        self.assertTrue(mailbox.folder_argument('订单邮件').isascii())
        with self.assertRaises(ValueError): mailbox.folder_argument('bad\nfolder')


class SyncTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=str(Path(self.temp.name)/'mail.db')
        self.cfg={'DATABASE_PATH':self.path,'ADMIN_PASSWORD':'test-password-strong','SECRET_KEY':'s'*40,'API_KEY':'k'*40,
                  'IMAP_HOST':'imap.example.test','IMAP_USER':'owner@example.test','IMAP_PASSWORD':'private-secret',
                  'IMAP_FOLDER':'INBOX','IMAP_ALLOWED_SENDERS':''}
        self.app=create_app(self.cfg)
        self.app.testing=True
        self.client=self.app.test_client()
        self.auth={'Authorization':'Bearer '+'k'*40}
        self.fake=FakeIMAP()
        self.factory=Mock(return_value=self.fake)
        self.now=core.now_utc()+timedelta(seconds=2)
    def tearDown(self): self.temp.cleanup()
    def tick(self,offset=0):
        return mailbox.sync_tick(self.path,self.cfg,factory=self.factory,now=self.now+timedelta(minutes=offset))
    def setup_baseline(self):
        mailbox.request_check(self.path)
        self.assertEqual(self.tick(),'initialized')
    def parcels(self):
        with core.database(self.path) as con: return [dict(row) for row in con.execute('SELECT * FROM parcels')]
    def test_disabled_does_not_connect(self):
        self.assertEqual(self.tick(),'idle')
        self.factory.assert_not_called()
    def test_initial_baseline_ignores_old_emails(self):
        self.setup_baseline()
        self.assertEqual(self.parcels(),[])
        self.assertEqual(mailbox.state(self.path,self.cfg)['last_uid'],1)
        self.assertTrue(self.fake.logged_out)
        self.assertIn(('select','"INBOX"',True),self.fake.calls)
        self.assertEqual(self.factory.call_args.kwargs['ssl_context'].verify_mode,ssl.CERT_REQUIRED)
    def test_new_email_import_and_repeat_dedup(self):
        self.setup_baseline()
        self.fake.messages[2]=message().as_bytes()
        mailbox.request_check(self.path)
        self.assertEqual(self.tick(1),'ok')
        self.assertEqual(len(self.parcels()),1)
        self.assertIn(('fetch','2','(BODY.PEEK[])'),self.fake.calls)
        self.fake.messages[3]=message().as_bytes()
        mailbox.request_check(self.path)
        self.tick(2)
        self.assertEqual(len(self.parcels()),1)
        self.assertEqual(mailbox.state(self.path,self.cfg)['last_imported'],0)
        with core.database(self.path) as con: self.assertEqual(con.execute('SELECT COUNT(*) FROM orders').fetchone()[0],1)
    def test_automatic_interval_and_independent_switch(self):
        mailbox.save(self.path,True,5)
        self.assertEqual(self.tick(),'initialized')
        self.assertEqual(self.tick(1),'idle')
        self.fake.messages[2]=message().as_bytes()
        self.assertEqual(self.tick(6),'ok')
        self.assertEqual(core.settings(self.path)['enabled'],0)
    def test_failure_keeps_cursor_and_sanitizes_error(self):
        self.setup_baseline()
        self.fake.messages[2]=message().as_bytes()
        self.fake.broken=2
        mailbox.request_check(self.path)
        self.assertEqual(self.tick(1),'error')
        state=mailbox.state(self.path,self.cfg)
        self.assertEqual(state['last_uid'],1)
        self.assertNotIn('private',state['last_error'])
        self.assertNotIn('password',str(state).lower())
        self.fake.broken=None
        mailbox.request_check(self.path)
        self.assertEqual(self.tick(2),'ok')
    def test_uidvalidity_or_folder_change_reinitializes(self):
        self.setup_baseline()
        self.fake.messages[2]=message().as_bytes()
        self.cfg['IMAP_FOLDER']='Orders'
        mailbox.request_check(self.path)
        self.assertEqual(self.tick(1),'initialized')
        self.assertEqual(self.parcels(),[])
        self.fake.validity=b'456'
        mailbox.request_check(self.path)
        self.assertEqual(self.tick(2),'initialized')
    def test_oversize_is_skipped_without_body_fetch(self):
        self.setup_baseline()
        self.fake.messages[2]=message().as_bytes()
        self.fake.size_override[2]=3*1024*1024
        mailbox.request_check(self.path)
        self.assertEqual(self.tick(1),'ok')
        self.assertNotIn(('fetch','2','(BODY.PEEK[])'),self.fake.calls)
        self.assertEqual(mailbox.state(self.path,self.cfg)['last_skipped'],1)
    def test_no_order_id_still_adds_parcel(self):
        self.setup_baseline()
        self.fake.messages[2]=message('运单号: SF1234567890').as_bytes()
        mailbox.request_check(self.path)
        self.tick(1)
        self.assertEqual(len(self.parcels()),1)
        self.assertEqual(self.parcels()[0]['order_id'],'')
    def test_concurrent_ticks_claim_once(self):
        mailbox.request_check(self.path)
        with ThreadPoolExecutor(max_workers=4) as pool:
            results=list(pool.map(lambda _:self.tick(),range(4)))
        self.assertEqual(results.count('initialized'),1)
        self.assertEqual(self.factory.call_count,1)
    def test_interrupted_manual_check_recovers_when_disabled(self):
        self.setup_baseline()
        with core.database(self.path) as con:
            con.execute("UPDATE mailbox_settings SET status='checking',lease_until=?,requested=0,enabled=0",(core.stamp(self.now-timedelta(minutes=1)),))
        self.assertEqual(self.tick(),'ok')
    def test_api_auth_settings_and_secret_not_exposed(self):
        self.assertEqual(self.client.get('/api/mailbox').status_code,401)
        result=self.client.get('/api/mailbox',headers=self.auth)
        self.assertEqual(result.status_code,200)
        self.assertNotIn('private-secret',result.text)
        self.assertNotIn('claim_token',result.json)
        self.assertEqual(self.client.put('/api/mailbox',headers=self.auth,json={'enabled':True,'interval_minutes':1}).status_code,200)
        for value in (0,1441,True,'5'):
            self.assertEqual(self.client.put('/api/mailbox',headers=self.auth,json={'enabled':True,'interval_minutes':value}).status_code,400)
        self.assertEqual(self.client.post('/api/mailbox/check',headers=self.auth).status_code,202)
    def test_email_to_weekly_digest_end_to_end(self):
        self.setup_baseline()
        self.fake.messages[2]=message().as_bytes()
        mailbox.request_check(self.path)
        self.assertEqual(self.tick(1),'ok')
        cfg={**self.cfg,'SMTP_FROM':'sender@example.test','MAIL_TO':'owner@example.test','INSTANCE_ID':'mail-test'}
        instant=self.now+timedelta(minutes=2)
        with core.database(self.path) as con:
            con.execute('UPDATE settings SET enabled=1,next_run=?',(core.stamp(instant-timedelta(seconds=1)),))
        sent=[]
        self.assertEqual(core.scheduler_tick(self.path,cfg,send=lambda msg,_:sent.append(msg),now=instant),'sent')
        self.assertIn('SF1234567890',sent[0].get_body(preferencelist=('plain',)).get_content())
        self.assertEqual(self.parcels()[0]['state'],'sent')

    def test_many_shipments_are_imported_without_order_limit_failure(self):
        self.setup_baseline()
        body='订单号: ORDER12345\n'+'\n'.join(f'运单号: SF{number:08d}' for number in range(30))
        self.fake.messages[2]=message(body).as_bytes()
        mailbox.request_check(self.path)
        self.assertEqual(self.tick(1),'ok')
        self.assertEqual(len(self.parcels()),30)

    def test_malformed_email_does_not_block_later_messages(self):
        self.setup_baseline()
        self.fake.messages[2]=message().as_bytes()
        mailbox.request_check(self.path)
        from unittest.mock import patch
        with patch('parcel_digest.mailbox.extract',side_effect=ValueError('bad MIME')):
            self.assertEqual(self.tick(1),'ok')
        self.assertEqual(mailbox.state(self.path,self.cfg)['last_uid'],2)
        self.fake.messages[3]=message().as_bytes()
        mailbox.request_check(self.path)
        self.assertEqual(self.tick(2),'ok')
        self.assertEqual(len(self.parcels()),1)

    def test_pickup_email_updates_existing_parcel_and_classification(self):
        from parcel_digest import pickup
        core.add_parcels(self.path,[{'tracking_number':'SF1234567890'}])
        self.setup_baseline()
        self.fake.messages[2]=message('运单号：SF1234567890\n取件码：3-1024\n取件地址：东门驿站。').as_bytes()
        mailbox.request_check(self.path)
        self.assertEqual(self.tick(1),'ok')
        self.assertEqual(len(self.parcels()),1)
        self.assertEqual(pickup.detail(self.path,1)['pickup_code'],'3-1024')
        self.assertEqual(self.client.get('/api/parcels?group=pickup',headers=self.auth).json['total'],1)

    def test_order_api_shows_linked_shipments(self):
        record={'platform':'京东','order_id':'ORDER001','shipments':[{'tracking_number':'JD123456'}]}
        self.assertEqual(self.client.post('/api/orders/import',headers=self.auth,json={'items':[record]}).status_code,201)
        result=self.client.get('/api/orders',headers=self.auth).json
        self.assertEqual(result['total'],1)
        self.assertEqual(result['items'][0]['shipments'][0]['tracking_number'],'JD123456')

if __name__=='__main__': unittest.main()


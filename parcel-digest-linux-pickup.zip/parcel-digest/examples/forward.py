"""Forward already-authorized order data; this script does not fetch platform orders.

PARCEL_BASE_URL=https://parcels.example.com PARCEL_API_KEY=... python3 examples/forward.py
Replace the sample `items` with records provided by your authorized data source.
"""
import json
import os
import urllib.request

items = [{"tracking_number": "SF1234567890", "platform": "抖音", "carrier": "顺丰", "note": "示例数据"}]
base = os.environ["PARCEL_BASE_URL"].rstrip("/")
if not base.startswith("https://") and not base.startswith("http://127.0.0.1:"):
    raise SystemExit("请使用 HTTPS 地址，或本机 127.0.0.1 调试地址")
request = urllib.request.Request(base + "/api/parcels", data=json.dumps({"items": items}).encode(),
                                 headers={"Authorization": "Bearer " + os.environ["PARCEL_API_KEY"],
                                          "Content-Type": "application/json"}, method="POST")
with urllib.request.urlopen(request, timeout=15) as response:
    print(response.read().decode())

from __future__ import annotations

import csv
import io
import json
import os
import re
import secrets
import smtplib
import sqlite3
import ssl
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage
from pathlib import Path
from zoneinfo import ZoneInfo

UTC = timezone.utc
PLATFORMS = ("淘宝/天猫", "京东", "拼多多", "小红书", "抖音", "闲鱼", "转转", "其他")


def now_utc():
    return datetime.now(UTC)


def stamp(value=None):
    return (value or now_utc()).astimezone(UTC).isoformat(timespec="seconds")


@contextmanager
def database(path):
    con = sqlite3.connect(path, timeout=30, isolation_level=None)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=30000")
    con.execute("PRAGMA foreign_keys=ON")
    try:
        yield con
    finally:
        con.close()


def next_run(now, weekday, hour, minute, tz_name):
    tz = ZoneInfo(tz_name)
    local = now.astimezone(tz)
    for day in range(15):
        date = local.date() + timedelta(days=day)
        if date.weekday() != weekday:
            continue
        candidate = datetime(date.year, date.month, date.day, hour, minute, tzinfo=tz)
        utc = candidate.astimezone(UTC)
        back = utc.astimezone(tz)
        if (back.date(), back.hour, back.minute) != (date, hour, minute):
            continue
        if utc > now:
            return stamp(utc)
    raise ValueError("无法计算下次发送时间")


def init_db(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with database(path) as con:
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript("""
            CREATE TABLE IF NOT EXISTS settings (
                id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 0,
                weekday INTEGER NOT NULL DEFAULT 0, hour INTEGER NOT NULL DEFAULT 9,
                minute INTEGER NOT NULL DEFAULT 0, timezone TEXT NOT NULL DEFAULT 'Asia/Shanghai',
                next_run TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS parcels (
                id INTEGER PRIMARY KEY, tracking_number TEXT NOT NULL UNIQUE,
                carrier TEXT NOT NULL, platform TEXT NOT NULL, order_id TEXT NOT NULL,
                note TEXT NOT NULL, created_at TEXT NOT NULL,
                state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','sent','excluded')),
                sent_at TEXT
            );
            CREATE TABLE IF NOT EXISTS deliveries (
                id INTEGER PRIMARY KEY, trigger TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'queued',
                created_at TEXT NOT NULL, sent_at TEXT, attempts INTEGER NOT NULL DEFAULT 0,
                retry_at TEXT NOT NULL, lease_until TEXT, claim_token TEXT,
                last_error TEXT NOT NULL DEFAULT '', recipient TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS delivery_items (
                delivery_id INTEGER NOT NULL REFERENCES deliveries(id),
                parcel_id INTEGER NOT NULL REFERENCES parcels(id),
                PRIMARY KEY(delivery_id, parcel_id)
            );
            CREATE INDEX IF NOT EXISTS idx_parcels_state ON parcels(state);
        """)
        con.execute("INSERT OR IGNORE INTO settings(id,next_run) VALUES(1,?)",
                    (next_run(now_utc(), 0, 9, 0, "Asia/Shanghai"),))


def settings(path):
    with database(path) as con:
        return dict(con.execute("SELECT * FROM settings WHERE id=1").fetchone())


def save_settings(path, enabled, weekday, hour, minute, tz_name):
    if not (0 <= weekday <= 6 and 0 <= hour <= 23 and 0 <= minute <= 59):
        raise ValueError("星期或时间不正确")
    ZoneInfo(tz_name)
    upcoming = next_run(now_utc(), weekday, hour, minute, tz_name)
    with database(path) as con:
        con.execute("UPDATE settings SET enabled=?,weekday=?,hour=?,minute=?,timezone=?,next_run=? WHERE id=1",
                    (int(enabled), weekday, hour, minute, tz_name, upcoming))


def normalize(item):
    if not isinstance(item, dict):
        raise ValueError("每条记录必须是对象")
    result = {}
    for key, limit in (("tracking_number", 80), ("carrier", 80), ("platform", 80),
                       ("order_id", 120), ("note", 500)):
        value = item.get(key, "")
        if value is None:
            value = ""
        if not isinstance(value, str):
            raise ValueError(f"{key} 必须是字符串，单号请用引号保留前导零")
        value = value.strip()
        if len(value) > limit or any(ord(ch) < 32 for ch in value):
            raise ValueError(f"{key} 过长或含有控制字符")
        result[key] = value
    result["tracking_number"] = result["tracking_number"].upper()
    if not re.fullmatch(r"[A-Z0-9][A-Z0-9-]{4,79}", result["tracking_number"]):
        raise ValueError("快递单号需为 5–80 位字母、数字或连字符")
    return result


def add_parcels(path, items):
    if not isinstance(items, list) or not 1 <= len(items) <= 1000:
        raise ValueError("每次需提交 1–1000 条单号")
    clean = [normalize(item) for item in items]
    inserted = 0
    with database(path) as con:
        con.execute("BEGIN IMMEDIATE")
        try:
            for item in clean:
                cursor = con.execute(
                    "INSERT OR IGNORE INTO parcels(tracking_number,carrier,platform,order_id,note,created_at) "
                    "VALUES(:tracking_number,:carrier,:platform,:order_id,:note,:created_at)",
                    {**item, "created_at": stamp()})
                inserted += cursor.rowcount
            con.commit()
        except Exception:
            con.rollback()
            raise
    return {"inserted": inserted, "duplicates": len(clean) - inserted}


def parse_csv(raw):
    try:
        reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig"), newline=""))
        if not reader.fieldnames or "tracking_number" not in reader.fieldnames:
            raise ValueError("CSV 必须包含 tracking_number 列，请下载模板")
        rows = []
        for row in reader:
            if len(rows) >= 1000:
                raise ValueError("每次最多导入 1000 行")
            if None in row:
                raise ValueError("CSV 行的列数超过表头，请检查逗号和引号")
            rows.append(row)
        return rows
    except UnicodeDecodeError as exc:
        raise ValueError("请将 CSV 保存为 UTF-8 编码") from exc


def queue_delivery(con, trigger, instant):
    if con.execute("SELECT 1 FROM deliveries WHERE status IN ('queued','sending')").fetchone():
        return "busy"
    ids = con.execute("SELECT id FROM parcels WHERE state='pending' ORDER BY id").fetchall()
    if not ids:
        return "empty"
    delivery_id = con.execute("INSERT INTO deliveries(trigger,created_at,retry_at) VALUES(?,?,?)",
                              (trigger, instant, instant)).lastrowid
    con.executemany("INSERT INTO delivery_items VALUES(?,?)", [(delivery_id, row[0]) for row in ids])
    return "queued"


def request_delivery(path):
    with database(path) as con:
        con.execute("BEGIN IMMEDIATE")
        result = queue_delivery(con, "manual", stamp())
        con.commit()
        return result


def change_state(path, parcel_id, state):
    if state not in ("pending", "excluded"):
        raise ValueError("状态不正确")
    with database(path) as con:
        con.execute("BEGIN IMMEDIATE")
        locked = con.execute(
            "SELECT 1 FROM delivery_items i JOIN deliveries d ON i.delivery_id=d.id "
            "WHERE i.parcel_id=? AND d.status IN ('queued','sending')", (parcel_id,)).fetchone()
        if locked:
            con.rollback()
            raise ValueError("该单号正在发送队列中，请等待发送结束")
        con.execute("UPDATE parcels SET state=? WHERE id=? AND state!='sent'", (state, parcel_id))
        con.commit()


def build_message(delivery_id, parcels, cfg, recipient):
    msg = EmailMessage()
    msg["From"] = cfg["SMTP_FROM"]
    msg["To"] = recipient
    msg["Subject"] = f"快递单号汇总 · {len(parcels)} 件 · {now_utc().astimezone(ZoneInfo('Asia/Shanghai')):%Y-%m-%d}"
    domain = cfg["SMTP_FROM"].rsplit("@", 1)[-1].strip("> ")
    msg["Message-ID"] = f"<parcel-digest-{cfg['INSTANCE_ID']}-{delivery_id}@{domain}>"
    lines = ["以下是尚未发送过的快递单号：", ""]
    for row in parcels:
        lines.extend([f"单号：{row['tracking_number']}",
                      f"平台：{row['platform'] or '未填写'}  |  快递：{row['carrier'] or '未填写'}",
                      f"订单号：{row['order_id'] or '未填写'}", f"备注：{row['note'] or '无'}", ""])
    lines.append("本邮件按新增单号汇总，不代表物流状态。")
    msg.set_content("\n".join(lines))
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["tracking_number", "carrier", "platform", "order_id", "note", "created_at"])
    for row in parcels:
        values = [str(row[key]) for key in ("tracking_number", "carrier", "platform", "order_id", "note", "created_at")]
        writer.writerow(["'" + value if value.startswith(("=", "+", "-", "@")) else value for value in values])
    msg.add_attachment(output.getvalue().encode("utf-8-sig"), maintype="text", subtype="csv", filename="parcels.csv")
    return msg


def smtp_send(msg, cfg):
    if any(not cfg.get(key) for key in ("SMTP_HOST", "SMTP_FROM", "MAIL_TO")):
        raise ValueError("邮件配置缺失：请设置 SMTP_HOST、SMTP_FROM 和 MAIL_TO")
    mode = cfg.get("SMTP_SECURITY", "starttls")
    port = int(cfg.get("SMTP_PORT", "465" if mode == "ssl" else "587"))
    context = ssl.create_default_context()
    if mode == "ssl":
        client = smtplib.SMTP_SSL(cfg["SMTP_HOST"], port, timeout=30, context=context)
    elif mode == "starttls":
        client = smtplib.SMTP(cfg["SMTP_HOST"], port, timeout=30)
    else:
        raise ValueError("SMTP_SECURITY 只支持 ssl 或 starttls")
    with client:
        if mode == "starttls":
            client.ehlo()
            client.starttls(context=context)
            client.ehlo()
        if cfg.get("SMTP_USER"):
            client.login(cfg["SMTP_USER"], cfg.get("SMTP_PASSWORD", ""))
        client.send_message(msg)


def scheduler_tick(path, cfg, send=smtp_send, now=None):
    current = now or now_utc()
    instant = stamp(current)
    claim = secrets.token_hex(16)
    with database(path) as con:
        con.execute("BEGIN IMMEDIATE")
        schedule = con.execute("SELECT * FROM settings WHERE id=1").fetchone()
        if schedule["enabled"] and schedule["next_run"] <= instant:
            queue_delivery(con, "weekly", instant)
            con.execute("UPDATE settings SET next_run=? WHERE id=1", (
                next_run(current, schedule["weekday"], schedule["hour"], schedule["minute"], schedule["timezone"]),))
        delivery = con.execute(
            "SELECT * FROM deliveries WHERE (status='queued' AND retry_at<=?) "
            "OR (status='sending' AND lease_until<=?) ORDER BY id LIMIT 1", (instant, instant)).fetchone()
        if not delivery:
            con.commit()
            return "idle"
        if delivery["attempts"] >= 5:
            con.execute("UPDATE deliveries SET status='failed',last_error='达到 5 次尝试上限，请检查后手动重发',lease_until=NULL,claim_token=NULL WHERE id=?", (delivery["id"],))
            con.commit()
            return "failed"
        recipient = delivery["recipient"] or cfg.get("MAIL_TO", "")
        con.execute(
            "UPDATE deliveries SET status='sending',attempts=attempts+1,lease_until=?,claim_token=?,recipient=? WHERE id=?",
            (stamp(current + timedelta(minutes=30)), claim, recipient, delivery["id"]))
        parcels = con.execute(
            "SELECT p.* FROM parcels p JOIN delivery_items i ON p.id=i.parcel_id WHERE i.delivery_id=? ORDER BY p.id",
            (delivery["id"],)).fetchall()
        con.commit()
    try:
        if not cfg.get("SMTP_FROM") or not recipient:
            raise ValueError("请配置 SMTP_FROM 和 MAIL_TO")
        send(build_message(delivery["id"], parcels, cfg, recipient), cfg)
    except Exception as exc:
        attempt = delivery["attempts"] + 1
        error = f"{type(exc).__name__}：邮件发送失败，请检查 SMTP 配置、授权码与网络"
        with database(path) as con:
            con.execute(
                "UPDATE deliveries SET status=?,retry_at=?,lease_until=NULL,claim_token=NULL,last_error=? WHERE id=? AND claim_token=?",
                ("failed" if attempt >= 5 else "queued", stamp(current + timedelta(minutes=min(60, 2 ** attempt))), error, delivery["id"], claim))
        return "failed" if attempt >= 5 else "retry"
    with database(path) as con:
        con.execute("BEGIN IMMEDIATE")
        changed = con.execute(
            "UPDATE deliveries SET status='sent',sent_at=?,lease_until=NULL,claim_token=NULL,last_error='' WHERE id=? AND claim_token=?",
            (stamp(), delivery["id"], claim)).rowcount
        if changed:
            con.execute(
                "UPDATE parcels SET state='sent',sent_at=? WHERE id IN (SELECT parcel_id FROM delivery_items WHERE delivery_id=?)",
                (stamp(), delivery["id"]))
        con.commit()
    return "sent"


def webhook_records(payload, spec):
    def field(obj, path, default=""):
        if not path:
            return default
        for part in path.split("."):
            if not isinstance(obj, dict) or part not in obj:
                return default
            obj = obj[part]
        return obj
    records = field(payload, spec.get("records_path"), payload)
    if isinstance(records, dict):
        records = [records]
    if not isinstance(records, list) or not 1 <= len(records) <= 1000:
        raise ValueError("Webhook 记录需为对象或包含 1–1000 条记录的数组")
    result = []
    for row in records:
        if not isinstance(row, dict):
            raise ValueError("Webhook 每条记录必须是对象")
        result.append({"tracking_number": field(row, spec.get("tracking_field", "tracking_number")),
                       "carrier": field(row, spec.get("carrier_field", "carrier")),
                       "order_id": field(row, spec.get("order_field", "order_id")),
                       "note": field(row, spec.get("note_field", "note")),
                       "platform": spec.get("label", "其他")})
    return result


def configuration():
    cfg = dict(os.environ)
    cfg.setdefault("DATABASE_PATH", "data/parcels.db")
    cfg.setdefault("INSTANCE_ID", "personal")
    if not re.fullmatch(r"[A-Za-z0-9-]{1,64}", cfg["INSTANCE_ID"]):
        raise ValueError("INSTANCE_ID 需为 1–64 位字母、数字或连字符")
    cfg["WEBHOOKS"] = json.loads(cfg.get("PLATFORM_WEBHOOKS_JSON", "{}"))
    return cfg

from __future__ import annotations

import hmac
import secrets
import threading
import time
from datetime import timedelta
from functools import wraps
from zoneinfo import ZoneInfoNotFoundError

from flask import Flask, Response, jsonify, redirect, render_template, request, session, url_for
from werkzeug.exceptions import BadRequest, RequestEntityTooLarge, UnsupportedMediaType

from . import core, orders, mailbox, tracking, pickup


def equal(left, right):
    return hmac.compare_digest(left.encode("utf-8"), right.encode("utf-8"))


def create_app(overrides=None):
    cfg = core.configuration()
    cfg.update(overrides or {})
    for key, minimum in (("ADMIN_PASSWORD", 12), ("API_KEY", 24), ("SECRET_KEY", 32)):
        if len(cfg.get(key, "")) < minimum:
            raise ValueError(f"{key} 必须配置且至少 {minimum} 位")
    app = Flask(__name__)
    app.config.update(cfg)
    app.config.update(MAX_CONTENT_LENGTH=2 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True,
                      SESSION_COOKIE_SAMESITE="Strict",
                      SESSION_COOKIE_SECURE=cfg.get("COOKIE_SECURE", "false").lower() == "true",
                      PERMANENT_SESSION_LIFETIME=timedelta(hours=12))
    core.init_db(cfg["DATABASE_PATH"])
    orders.init_orders(cfg["DATABASE_PATH"])
    mailbox.init_mailbox(cfg["DATABASE_PATH"])
    tracking.init_tracking(cfg["DATABASE_PATH"])
    pickup.init_pickup(cfg["DATABASE_PATH"])
    failures = {}
    failure_lock = threading.Lock()

    def protected(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            auth = request.headers.get("Authorization", "")
            if auth:
                if not equal(auth, f"Bearer {cfg['API_KEY']}"):
                    return jsonify(error="API 密钥无效"), 401
            elif session.get("authenticated"):
                if request.method not in ("GET", "HEAD", "OPTIONS"):
                    if not equal(request.headers.get("X-CSRF-Token", ""), session.get("csrf", "missing")):
                        return jsonify(error="页面会话失效，请刷新后重试"), 403
            else:
                return jsonify(error="请先登录或使用 API 密钥"), 401
            return fn(*args, **kwargs)
        return wrapper

    @app.after_request
    def headers(response):
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
        return response

    @app.errorhandler(ValueError)
    @app.errorhandler(ZoneInfoNotFoundError)
    def invalid(error):
        return jsonify(error=str(error)), 400

    @app.errorhandler(BadRequest)
    @app.errorhandler(UnsupportedMediaType)
    def bad_json(error):
        return jsonify(error="请求格式不正确，请提交合法 JSON"), 400

    @app.errorhandler(RequestEntityTooLarge)
    def too_large(error):
        return jsonify(error="每次上传不得超过 2 MB"), 413

    def body():
        value = request.get_json()
        if not isinstance(value, dict):
            raise ValueError("请求体必须是 JSON 对象")
        return value

    @app.get("/healthz")
    def health():
        with core.database(cfg["DATABASE_PATH"]) as con:
            con.execute("SELECT 1").fetchone()
        return jsonify(status="ok")

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if "login_csrf" not in session:
            session["login_csrf"] = secrets.token_urlsafe(32)
        error = ""
        code = 200
        if request.method == "POST":
            ip = request.remote_addr or "unknown"
            with failure_lock:
                now = time.monotonic()
                for old in list(failures):
                    failures[old] = [t for t in failures[old] if now - t < 900]
                    if not failures[old]:
                        del failures[old]
                limited = len(failures.get(ip, [])) >= 10
            if limited:
                error, code = "尝试过于频繁，请 15 分钟后重试", 429
            elif not equal(request.form.get("csrf", ""), session["login_csrf"]):
                error, code = "页面已过期，请刷新", 403
            elif equal(request.form.get("password", ""), cfg["ADMIN_PASSWORD"]):
                session.clear()
                session["authenticated"] = True
                session["csrf"] = secrets.token_urlsafe(32)
                session.permanent = True
                return redirect(url_for("index"))
            else:
                with failure_lock:
                    failures.setdefault(ip, []).append(time.monotonic())
                error, code = "密码不正确", 401
        return render_template("login.html", error=error), code

    @app.get("/")
    def index():
        if not session.get("authenticated"):
            return redirect(url_for("login"))
        configured = all(cfg.get(k) for k in ("SMTP_HOST", "SMTP_FROM", "MAIL_TO"))
        return render_template("index.html", platforms=core.PLATFORMS,
                               mail_configured=configured, recipient=cfg.get("MAIL_TO", "未配置"),
                               webhooks=cfg.get("WEBHOOKS", {}))

    @app.post("/api/logout")
    @protected
    def logout():
        session.clear()
        return jsonify(ok=True)

    @app.get("/api/parcels")
    @protected
    def list_parcels():
        page = max(1, min(int(request.args.get("page", 1)), 1000000))
        state = request.args.get("state", "")
        if state not in ("", "pending", "sent", "excluded"):
            raise ValueError("状态不正确")
        search = request.args.get("q", "").strip()[:120]
        group = request.args.get("group", "")
        if group and group not in pickup.GROUPS:
            raise ValueError("包裹分类不正确")
        clauses, values = [], []
        if state:
            clauses.append("p.state=?")
            values.append(state)
        if search:
            clauses.append("(p.tracking_number LIKE ? OR p.platform LIKE ? OR p.order_id LIKE ? OR p.note LIKE ? OR k.pickup_code LIKE ? OR k.pickup_address LIKE ?)")
            values.extend([f"%{search}%"] * 6)
        base_where = " WHERE " + " AND ".join(clauses) if clauses else ""
        if group:
            clauses.append("(" + pickup.GROUP_SQL + ")=?")
            values.append(group)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        joined = " FROM parcels p LEFT JOIN parcel_tracking t ON p.id=t.parcel_id LEFT JOIN parcel_pickup k ON p.id=k.parcel_id"
        with core.database(cfg["DATABASE_PATH"]) as con:
            total = con.execute("SELECT COUNT(*)" + joined + where, values).fetchone()[0]
            group_values = values[:-1] if group else values
            group_counts = {row[0]: row[1] for row in con.execute("SELECT " + pickup.GROUP_SQL + " AS parcel_group,COUNT(*)" + joined + base_where + " GROUP BY parcel_group", group_values)}
            rows = con.execute("SELECT p.*,t.status AS logistics_status,t.last_success AS logistics_updated_at,t.error AS logistics_error,t.requested AS logistics_requested,t.lease_until AS logistics_lease,t.events_json AS logistics_events,t.provider AS logistics_provider,k.pickup_code,k.pickup_address,k.pickup_state,k.source AS pickup_source,k.arrived_at,k.collected_at," + pickup.GROUP_SQL + " AS parcel_group" + joined + where + " ORDER BY p.id DESC LIMIT 50 OFFSET ?", [*values, (page-1)*50]).fetchall()
            counts = {row[0]: row[1] for row in con.execute("SELECT state,COUNT(*) FROM parcels GROUP BY state")}
        items = []
        for row in rows:
            item = dict(row)
            events = tracking.json.loads(item.pop("logistics_events") or "[]")
            item["logistics_latest"] = events[0] if events else None
            item["logistics_status"] = item["logistics_status"] or "unknown"
            item["logistics_label"] = tracking.STATUS_NAMES.get(item["logistics_status"], "尚无物流状态")
            item["group_label"] = pickup.GROUPS[item["parcel_group"]]
            item["pickup_code"] = item["pickup_code"] or ""
            item["pickup_address"] = item["pickup_address"] or ""
            items.append(item)
        return jsonify(items=items, total=total, page=page, counts=counts, group_counts=group_counts)

    @app.post("/api/parcels")
    @protected
    def insert_parcels():
        payload = body()
        return jsonify(core.add_parcels(cfg["DATABASE_PATH"], payload.get("items", [payload]))), 201

    @app.patch("/api/parcels/<int:parcel_id>")
    @protected
    def parcel_state(parcel_id):
        core.change_state(cfg["DATABASE_PATH"], parcel_id, body().get("state"))
        return jsonify(ok=True)

    @app.post("/api/import")
    @protected
    def import_csv():
        upload = request.files.get("file")
        if not upload:
            raise ValueError("请选择 CSV 文件")
        return jsonify(core.add_parcels(cfg["DATABASE_PATH"], core.parse_csv(upload.read())))

    @app.get("/api/template.csv")
    @protected
    def template():
        return Response("\ufefftracking_number,carrier,platform,order_id,note\r\nSF1234567890,顺丰,淘宝/天猫,ORDER001,示例请替换\r\n",
                        content_type="text/csv; charset=utf-8", headers={"Content-Disposition": "attachment; filename=parcels-template.csv"})

    @app.get("/api/parcels/<int:parcel_id>/pickup")
    @protected
    def pickup_detail(parcel_id):
        return jsonify(pickup.detail(cfg["DATABASE_PATH"], parcel_id))

    @app.put("/api/parcels/<int:parcel_id>/pickup")
    @protected
    def update_pickup(parcel_id):
        return jsonify(pickup.update(cfg["DATABASE_PATH"], parcel_id, body()))

    @app.post("/api/parcels/<int:parcel_id>/pickup/collect")
    @protected
    def collect_pickup(parcel_id):
        return jsonify(pickup.collect(cfg["DATABASE_PATH"], parcel_id))

    @app.post("/api/parcels/<int:parcel_id>/pickup/automatic")
    @protected
    def automatic_pickup(parcel_id):
        pickup.allow_updates(cfg["DATABASE_PATH"], parcel_id)
        return jsonify(pickup.detail(cfg["DATABASE_PATH"], parcel_id))

    @app.get("/api/tracking/settings")
    @protected
    def tracking_settings():
        return jsonify(tracking.settings(cfg["DATABASE_PATH"], cfg))

    @app.put("/api/tracking/settings")
    @protected
    def update_tracking_settings():
        data = body()
        if data.get("enabled") and not tracking.configured(cfg):
            raise ValueError("尚未配置物流查询服务，请先在 .env 配置并重启")
        tracking.save_settings(cfg["DATABASE_PATH"], data.get("enabled"), data.get("interval_minutes"))
        return jsonify(tracking.settings(cfg["DATABASE_PATH"], cfg))

    @app.get("/api/parcels/<int:parcel_id>/tracking")
    @protected
    def tracking_detail(parcel_id):
        return jsonify(tracking.detail(cfg["DATABASE_PATH"], parcel_id, cfg))

    @app.put("/api/parcels/<int:parcel_id>/tracking")
    @protected
    def update_parcel_tracking(parcel_id):
        tracking.save_parcel(cfg["DATABASE_PATH"], parcel_id, body())
        return jsonify(tracking.detail(cfg["DATABASE_PATH"], parcel_id, cfg))

    @app.post("/api/parcels/<int:parcel_id>/tracking/refresh")
    @protected
    def refresh_tracking(parcel_id):
        result = tracking.request_refresh(cfg["DATABASE_PATH"], parcel_id, cfg)
        return jsonify(status=result), 202

    @app.get("/api/mailbox")
    @protected
    def mailbox_state():
        return jsonify(mailbox.state(cfg["DATABASE_PATH"], cfg))

    @app.put("/api/mailbox")
    @protected
    def mailbox_settings():
        data = body()
        if data.get("enabled") and not mailbox.configured(cfg):
            raise ValueError("请先配置 IMAP 邮箱并重启服务")
        mailbox.save(cfg["DATABASE_PATH"], data.get("enabled"), data.get("interval_minutes"))
        return jsonify(mailbox.state(cfg["DATABASE_PATH"], cfg))

    @app.post("/api/mailbox/check")
    @protected
    def check_mailbox():
        if not mailbox.configured(cfg):
            raise ValueError("请先配置 IMAP 邮箱并重启服务")
        mailbox.request_check(cfg["DATABASE_PATH"])
        return jsonify(status="queued"), 202

    @app.get("/api/orders")
    @protected
    def list_orders():
        page = max(1, min(int(request.args.get("page", 1)), 1000000))
        with core.database(cfg["DATABASE_PATH"]) as con:
            total = con.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
            rows = con.execute("SELECT * FROM orders ORDER BY last_seen DESC,id DESC LIMIT 50 OFFSET ?", ((page-1)*50,)).fetchall()
            items = []
            for row in rows:
                item = dict(row)
                item["shipments"] = [dict(shipment) for shipment in con.execute(
                    "SELECT p.tracking_number,p.carrier,p.state FROM order_shipments s JOIN parcels p ON s.tracking_number=p.tracking_number WHERE s.order_pk=?", (row["id"],))]
                items.append(item)
        return jsonify(items=items, total=total, page=page)

    @app.post("/api/orders/import")
    @protected
    def import_orders():
        return jsonify(orders.ingest_orders(cfg["DATABASE_PATH"], body().get("items"))), 201

    @app.get("/api/settings")
    @protected
    def get_settings():
        return jsonify(core.settings(cfg["DATABASE_PATH"]))

    @app.put("/api/settings")
    @protected
    def update_settings():
        data = body()
        if type(data.get("enabled")) is not bool:
            raise ValueError("enabled 必须是 true 或 false")
        for key in ("weekday", "hour", "minute"):
            if type(data.get(key)) is not int:
                raise ValueError(f"{key} 必须是整数")
        if not isinstance(data.get("timezone"), str) or len(data["timezone"]) > 80:
            raise ValueError("请填写有效时区")
        core.save_settings(cfg["DATABASE_PATH"], data["enabled"], data["weekday"], data["hour"], data["minute"], data["timezone"])
        return jsonify(core.settings(cfg["DATABASE_PATH"]))

    @app.post("/api/send")
    @protected
    def send_now():
        if not all(cfg.get(k) for k in ("SMTP_HOST", "SMTP_FROM", "MAIL_TO")):
            return jsonify(error="请先在 .env 配置邮件服务，再重启服务"), 400
        result = core.request_delivery(cfg["DATABASE_PATH"])
        return jsonify(status=result), 202 if result == "queued" else 200

    @app.get("/api/deliveries")
    @protected
    def deliveries():
        with core.database(cfg["DATABASE_PATH"]) as con:
            rows = con.execute(
                "SELECT d.*, (SELECT COUNT(*) FROM delivery_items i WHERE i.delivery_id=d.id) AS count "
                "FROM deliveries d ORDER BY d.id DESC LIMIT 30").fetchall()
        return jsonify(items=[dict(row) for row in rows])

    @app.post("/api/deliveries/<int:delivery_id>/cancel")
    @protected
    def cancel(delivery_id):
        with core.database(cfg["DATABASE_PATH"]) as con:
            changed = con.execute("UPDATE deliveries SET status='cancelled' WHERE id=? AND status='queued'", (delivery_id,)).rowcount
        if not changed:
            raise ValueError("仅等待中或等待重试的任务可以取消；已开始的发送无法撤回")
        return jsonify(ok=True)

    @app.post("/api/webhooks/<source>")
    def webhook(source):
        spec = cfg.get("WEBHOOKS", {}).get(source)
        if not spec:
            return jsonify(error="该来源尚未配置"), 404
        token = request.headers.get("X-Webhook-Token", "")
        if len(spec.get("token", "")) < 24 or not equal(token, spec["token"]):
            return jsonify(error="Webhook 密钥无效"), 401
        return jsonify(core.add_parcels(cfg["DATABASE_PATH"], core.webhook_records(request.get_json(), spec))), 201

    return app

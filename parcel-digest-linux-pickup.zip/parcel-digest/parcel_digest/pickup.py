"""Pickup notifications and grouping, kept separate from carrier delivery and email state."""
import re
from . import core

CODE = re.compile(r'(?:取件码|取货码|提货码|取件密码|提货密码)\s*[:：为是]?\s*([A-Za-z0-9][A-Za-z0-9\-－]{2,31})(?![A-Za-z0-9\-－])')
ADDRESS = re.compile(r'(?:取件地址|取货地址|提货地址|自提地址|驿站地址|取件地点|自提点|取件点)\s*[:：]\s*(.{1,500}?)(?=[\r\n；;。]|[，,]?\s*(?:取件码|提货码|取货码|运单号|快递单号|订单号|联系电话|营业时间|截止时间)\s*[:：]|$)')
READY = re.compile(r'待取件|等待(?:您|你)?(?:领取|取件)|(?:已入柜|已放入快递柜)|(?:已到达|已送达|已到|已送至|已放至).{0,40}(?:驿站|快递柜|自提柜|代收点|自提点)')
COLLECTED = re.compile(r'您已取件|用户已取件|收件人已取件|已完成自提|取件成功|包裹已取走|您已领取|已提货')
GROUP_SQL = """CASE
    WHEN p.state='excluded' THEN 'excluded'
    WHEN k.pickup_state='collected' OR t.status='returned' THEN 'completed'
    WHEN t.status='picked_up' AND COALESCE(k.manual_lock,0)=0 THEN 'completed'
    WHEN k.pickup_state='ready' OR (t.status='ready_for_pickup' AND COALESCE(k.manual_lock,0)=0) THEN 'pickup'
    WHEN t.status IN ('collected','in_transit','out_for_delivery','returning') THEN 'transit'
    WHEN t.status='delivered' THEN 'completed'
    WHEN t.status='exception' THEN 'exception'
    ELSE 'other' END"""
GROUPS = {'pickup':'待取件','transit':'运输中','completed':'已完成 / 已退回','exception':'物流异常','other':'待确认','excluded':'已排除'}


def init_pickup(path):
    with core.database(path) as con:
        con.executescript('''CREATE TABLE IF NOT EXISTS parcel_pickup (
            parcel_id INTEGER PRIMARY KEY REFERENCES parcels(id),
            pickup_code TEXT NOT NULL DEFAULT '', pickup_address TEXT NOT NULL DEFAULT '',
            pickup_state TEXT NOT NULL DEFAULT 'none' CHECK(pickup_state IN ('none','ready','collected')),
            source TEXT NOT NULL DEFAULT '', manual_lock INTEGER NOT NULL DEFAULT 0,
            arrived_at TEXT NOT NULL DEFAULT '', collected_at TEXT NOT NULL DEFAULT '',
            updated_at TEXT NOT NULL DEFAULT ''
        );''')


def extract_notice(text):
    codes=list(dict.fromkeys(match.replace('－','-') for match in CODE.findall(text) if any(c.isdigit() for c in match)))
    addresses=list(dict.fromkeys(' '.join(match.strip(' ，,').split()) for match in ADDRESS.findall(text)))
    # A summary email can contain multiple pickup codes; do not guess their association.
    code=codes[0] if len(codes)==1 else ''
    address=addresses[0] if len(addresses)==1 else ''
    state='collected' if COLLECTED.search(text) else ('ready' if code or READY.search(text) else '')
    return {'pickup_code':code,'pickup_address':address,'pickup_state':state}


def validate(values):
    if not isinstance(values,dict): raise ValueError('取件信息必须是对象')
    result={}
    for key,limit in (('pickup_code',32),('pickup_address',500)):
        value=values.get(key,'')
        if not isinstance(value,str) or len(value)>limit or any(ord(c)<32 for c in value):
            raise ValueError('取件码或取件地址格式不正确')
        result[key]=value.strip()
    state=values.get('pickup_state','')
    if state not in ('','none','ready','collected'): raise ValueError('取件状态不正确')
    result['pickup_state']=state
    return result


def apply(con, parcel_id, values, source, manual=False):
    values=validate(values)
    if not con.execute('SELECT 1 FROM parcels WHERE id=?',(parcel_id,)).fetchone(): raise ValueError('单号记录不存在')
    con.execute('INSERT OR IGNORE INTO parcel_pickup(parcel_id) VALUES(?)',(parcel_id,))
    old=con.execute('SELECT * FROM parcel_pickup WHERE parcel_id=?',(parcel_id,)).fetchone()
    if not manual and (old['manual_lock'] or old['pickup_state']=='collected'): return False
    if not manual and not any(values.values()): return False
    state=values['pickup_state'] or old['pickup_state']
    code=values['pickup_code'] if manual else (values['pickup_code'] or old['pickup_code'])
    address=values['pickup_address'] if manual else (values['pickup_address'] or old['pickup_address'])
    arrived=old['arrived_at']
    collected=old['collected_at']
    instant=core.stamp()
    if state=='ready' and (not arrived or (manual and old['pickup_state']!='ready')): arrived=instant
    if state=='collected': collected=collected or instant
    if manual and state!='collected': collected=''
    if manual and state=='none': arrived=''
    con.execute('''UPDATE parcel_pickup SET pickup_code=?,pickup_address=?,pickup_state=?,source=?,manual_lock=?,
        arrived_at=?,collected_at=?,updated_at=? WHERE parcel_id=?''',
        (code,address,state,source,int(manual),arrived,collected,instant,parcel_id))
    return True


def update(path,parcel_id,values):
    values=validate(values)
    if not values['pickup_state']: raise ValueError('请选择取件状态')
    with core.database(path) as con:
        con.execute('BEGIN IMMEDIATE')
        apply(con,parcel_id,values,'manual',manual=True)
        con.commit()
    return detail(path,parcel_id)


def detail(path,parcel_id):
    with core.database(path) as con:
        if not con.execute('SELECT 1 FROM parcels WHERE id=?',(parcel_id,)).fetchone(): raise ValueError('单号记录不存在')
        row=con.execute('SELECT * FROM parcel_pickup WHERE parcel_id=?',(parcel_id,)).fetchone()
    if row: return dict(row)
    return {'parcel_id':parcel_id,'pickup_code':'','pickup_address':'','pickup_state':'none','source':'','manual_lock':0,'arrived_at':'','collected_at':'','updated_at':''}


def automatic(path,number,values,source):
    if source not in ('email','tracking'): raise ValueError('取件信息来源不正确')
    with core.database(path) as con:
        con.execute('BEGIN IMMEDIATE')
        row=con.execute('SELECT id FROM parcels WHERE tracking_number=?',(number,)).fetchone()
        if row: apply(con,row['id'],values,source)
        con.commit()


def collect(path,parcel_id):
    with core.database(path) as con:
        con.execute('BEGIN IMMEDIATE')
        if not con.execute('SELECT 1 FROM parcels WHERE id=?',(parcel_id,)).fetchone(): raise ValueError('单号记录不存在')
        row=con.execute('SELECT * FROM parcel_pickup WHERE parcel_id=?',(parcel_id,)).fetchone()
        apply(con,parcel_id,{'pickup_code':row['pickup_code'] if row else '',
                           'pickup_address':row['pickup_address'] if row else '', 'pickup_state':'collected'},'manual',manual=True)
        con.commit()
    return detail(path,parcel_id)


def allow_updates(path,parcel_id):
    with core.database(path) as con:
        if not con.execute('SELECT 1 FROM parcels WHERE id=?',(parcel_id,)).fetchone(): raise ValueError('单号记录不存在')
        con.execute('UPDATE parcel_pickup SET manual_lock=0 WHERE parcel_id=?',(parcel_id,))

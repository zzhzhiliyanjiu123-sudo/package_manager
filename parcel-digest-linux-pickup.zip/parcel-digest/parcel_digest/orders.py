"""Persist order snapshots and extract shipments into the parcel inbox."""
from . import core


def init_orders(path):
    with core.database(path) as con:
        con.executescript("""
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY,
                platform TEXT NOT NULL,
                order_id TEXT NOT NULL,
                title TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT '',
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL,
                UNIQUE(platform, order_id)
            );
            CREATE TABLE IF NOT EXISTS order_shipments (
                order_pk INTEGER NOT NULL REFERENCES orders(id),
                tracking_number TEXT NOT NULL,
                PRIMARY KEY(order_pk, tracking_number)
            );
        """)


def text(item, key, limit, required=False):
    value = item.get(key, "")
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 for c in value):
        raise ValueError(f"订单字段 {key} 格式不正确")
    value = value.strip()
    if required and not value:
        raise ValueError(f"订单字段 {key} 不能为空")
    return value


def ingest_orders(path, records):
    if not isinstance(records, list) or not 1 <= len(records) <= 1000:
        raise ValueError("每次需提交 1–1000 条订单")
    normalized = []
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("订单必须是对象")
        order = {key: text(record, key, limit, required) for key, limit, required in (
            ("platform", 80, True), ("order_id", 120, True), ("title", 500, False), ("status", 80, False))}
        shipments = record.get("shipments", [])
        if not isinstance(shipments, list) or len(shipments) > 20:
            raise ValueError("每个订单的 shipments 必须是数组，最多 20 个包裹")
        clean = []
        for shipment in shipments:
            if not isinstance(shipment, dict):
                raise ValueError("包裹必须是对象")
            clean.append(core.normalize({**shipment, "platform": order["platform"],
                                         "order_id": order["order_id"], "note": order["title"]}))
        normalized.append((order, clean))
    inserted = 0
    with core.database(path) as con:
        con.execute("BEGIN IMMEDIATE")
        try:
            for order, shipments in normalized:
                instant = core.stamp()
                con.execute("""
                    INSERT INTO orders(platform,order_id,title,status,first_seen,last_seen)
                    VALUES(:platform,:order_id,:title,:status,:instant,:instant)
                    ON CONFLICT(platform,order_id) DO UPDATE SET
                    title=CASE WHEN excluded.title!='' THEN excluded.title ELSE orders.title END,
                    status=CASE WHEN excluded.status!='' THEN excluded.status ELSE orders.status END,
                    last_seen=excluded.last_seen
                """, {**order, "instant": instant})
                order_pk = con.execute("SELECT id FROM orders WHERE platform=? AND order_id=?",
                                       (order["platform"], order["order_id"])).fetchone()[0]
                for shipment in shipments:
                    inserted += con.execute("""
                        INSERT OR IGNORE INTO parcels(tracking_number,carrier,platform,order_id,note,created_at)
                        VALUES(:tracking_number,:carrier,:platform,:order_id,:note,:instant)
                    """, {**shipment, "instant": instant}).rowcount
                    con.execute("INSERT OR IGNORE INTO order_shipments VALUES(?,?)",
                                (order_pk, shipment["tracking_number"]))
            con.commit()
        except Exception:
            con.rollback()
            raise
    return {"orders_processed": len(normalized), "parcels_inserted": inserted}

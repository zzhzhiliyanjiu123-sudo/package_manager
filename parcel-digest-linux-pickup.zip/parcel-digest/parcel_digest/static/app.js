const csrf = document.querySelector('meta[name="csrf-token"]').content;
const $ = (id) => document.getElementById(id);
let page = 1, query = '', state = '', group = '', total = 0, refreshing = false;
const statusNames = {pending:'等待汇总',sent:'已发送',excluded:'已排除',queued:'等待发送 / 重试',sending:'发送中',failed:'发送失败',cancelled:'已取消'};
function notice(message, error = false) {
  const box = $('notice'); box.textContent = message; box.className = error ? 'error' : 'success'; box.hidden = false;
}
async function api(path, options = {}) {
  const headers = {'X-CSRF-Token':csrf, ...options.headers};
  if (options.body && !(options.body instanceof FormData)) headers['Content-Type'] = 'application/json';
  const response = await fetch(path, {...options, headers});
  if (response.status === 401) {location.href = '/login'; throw new Error('登录已过期');}
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || '请求失败，请稍后再试');
  return result;
}
function node(tag, text, className) {
  const element = document.createElement(tag); if (text !== undefined) element.textContent = text;
  if (className) element.className = className; return element;
}
function date(value, zone = 'Asia/Shanghai') {
  return value ? new Date(value).toLocaleString('zh-CN', {timeZone:zone, hour12:false}) : '—';
}
function badge(value) {return node('span', statusNames[value] || value, 'badge ' + value);}
function cell(primary, secondary, mono = false) {
  const td = node('td'); td.append(node(mono ? 'strong' : 'span', primary || '—'));
  if (secondary) td.append(node('small', secondary)); return td;
}
async function loadParcels() {
  const result = await api(`/api/parcels?${new URLSearchParams({page,q:query,state,group})}`);
  total = result.total; $('pending-count').textContent = result.counts.pending || 0; $('sent-count').textContent = result.counts.sent || 0;
  for(const count of document.querySelectorAll('[data-count]')){
    count.textContent=count.dataset.count==='all' ? Object.values(result.group_counts).reduce((a,b)=>a+b,0) : (result.group_counts[count.dataset.count] || 0);
  }
  for(const button of document.querySelectorAll('[data-group]'))button.setAttribute('aria-pressed',String(button.dataset.group===group));
  const body = $('parcels'); body.replaceChildren();
  if (!result.items.length) {const td = node('td', group ? '这个分类下暂无包裹。' : '暂无记录。添加单号或导入 CSV，开始收集。', 'empty'); td.colSpan = 7; const tr = node('tr'); tr.append(td); body.append(tr);}
  for (const item of result.items) {
    const row = node('tr'); row.append(cell(item.tracking_number,item.carrier,true),cell(item.platform,item.order_id),cell(item.note),cell(date(item.created_at)));
    const status = node('td'); status.append(badge(item.state)); row.append(status);
    const logistics = node('td');
    logistics.append(node('span',item.group_label,'badge group-'+item.parcel_group));
    if(item.parcel_group==='pickup'){
      logistics.append(node('strong',item.pickup_code || '取件码待补充','pickup-code'));
      logistics.append(node('p',item.pickup_address || '取件地址待补充','pickup-address'));
      if(item.arrived_at)logistics.append(node('small',`到站信息记录：${date(item.arrived_at)}`));
    }else{
      logistics.append(node('small',item.pickup_state==='collected' ? '已确认取件' : item.logistics_label));
      if(item.logistics_latest)logistics.append(node('p',item.logistics_latest.description.slice(0,180),'logistics-latest'));
      if(item.logistics_latest?.time)logistics.append(node('small',`轨迹时间：${item.logistics_latest.time}`));
      if(item.logistics_latest?.location)logistics.append(node('small',item.logistics_latest.location));
      logistics.append(node('small',item.logistics_updated_at ? `更新：${date(item.logistics_updated_at)}` : '尚未查询物流'));
    }
    if(item.logistics_requested || (item.logistics_lease && new Date(item.logistics_lease)>new Date())) logistics.append(node('small','等待查询 / 查询中'));
    if(item.logistics_error) logistics.append(node('small','查询异常，查看详情','error'));
    row.append(logistics);
    const actions = node('td');
    const detailsButton=node('button',item.parcel_group==='pickup' ? '取件详情 / 编辑' : '物流 / 取件详情','secondary tiny');
    detailsButton.addEventListener('click',()=>openTracking(item.id).catch(error=>notice(error.message,true)));
    actions.append(detailsButton);
    if(item.parcel_group==='pickup'){
      const collectButton=node('button','已取件','tiny');
      collectButton.addEventListener('click',()=>run(collectButton,async()=>{
        await api(`/api/parcels/${item.id}/pickup/collect`,{method:'POST'});notice('已标记取件，移入已完成分类。');await refresh();
      }));actions.append(collectButton);
    }
    if (item.state !== 'sent') {
      const button = node('button', item.state === 'pending' ? '排除' : '恢复', 'quiet tiny');
      button.addEventListener('click', () => run(button, async () => {await api(`/api/parcels/${item.id}`, {method:'PATCH',body:JSON.stringify({state:item.state === 'pending' ? 'excluded' : 'pending'})}); await refresh();}));
      actions.append(button);
    }
    row.append(actions); body.append(row);
  }
  $('page-label').textContent = `第 ${page} / ${Math.max(1,Math.ceil(total/50))} 页 · 共 ${total} 条`;
  $('prev').disabled = page <= 1; $('next').disabled = page * 50 >= total;
}
function showSettings(s, fields = false) {
  $('schedule-state').textContent = s.enabled ? '已开启' : '已关闭';
  $('next-run').textContent = s.enabled ? `下次：${date(s.next_run,s.timezone)}（${s.timezone}）` : '单号照常保存，等待你开启';
  if (fields) {$('enabled').checked=!!s.enabled; $('weekday').value=s.weekday; $('send-time').value=`${String(s.hour).padStart(2,'0')}:${String(s.minute).padStart(2,'0')}`; $('timezone').value=s.timezone;}
}
async function loadDeliveries() {
  const result = await api('/api/deliveries'); const box = $('deliveries'); box.replaceChildren();
  if (!result.items.length) box.append(node('p','还没有发送记录。','muted small'));
  for (const item of result.items) {
    const row = node('div',undefined,'history-row'); const info = node('div');
    info.append(node('p',`${item.trigger === 'weekly' ? '每周汇总' : '手动汇总'} · ${item.count} 件 · ${date(item.created_at)}`));
    info.append(node('p',`${item.recipient || '待分配收件人'} · 已尝试 ${item.attempts} 次`,'small muted'));
    if (item.last_error) info.append(node('p',item.last_error,'small error'));
    if (item.status === 'queued' && item.attempts) info.append(node('p',`计划重试：${date(item.retry_at)}`,'small muted'));
    row.append(info,badge(item.status));
    if (item.status === 'queued') {
      const button = node('button','取消','quiet tiny');
      button.addEventListener('click', () => run(button,async()=>{await api(`/api/deliveries/${item.id}/cancel`,{method:'POST'}); notice('任务已取消，单号保留为等待汇总。'); await refresh();})); row.append(button);
    }
    box.append(row);
  }
}
async function refresh() {
  if (refreshing) return; refreshing = true;
  try {await Promise.all([loadParcels(),loadDeliveries(),loadOrders(),loadMailbox(),loadTrackingSettings(),refreshOpenTracking(),api('/api/settings').then(s=>showSettings(s))]);}
  finally {refreshing = false;}
}
async function run(button, action) {
  button.disabled=true;
  try {await action();} catch(error) {notice(error.message,true); if($('tracking-dialog')?.open)$('tracking-error').textContent=error.message;} finally {button.disabled=false;}
}
$('add-form').addEventListener('submit', event => {
  event.preventDefault(); const form=event.currentTarget;
  run(form.querySelector('button'),async()=>{const result=await api('/api/parcels',{method:'POST',body:JSON.stringify(Object.fromEntries(new FormData(form)))}); notice(`已添加 ${result.inserted} 条，跳过重复 ${result.duplicates} 条。`); form.reset(); page=1; await refresh();});
});
$('import-form').addEventListener('submit',event=>{event.preventDefault();const form=event.currentTarget;run(form.querySelector('button'),async()=>{const result=await api('/api/import',{method:'POST',body:new FormData(form)}); notice(`导入成功：新增 ${result.inserted} 条，重复 ${result.duplicates} 条。`); form.reset();page=1;await refresh();});});
$('schedule-form').addEventListener('submit',event=>{event.preventDefault();run(event.currentTarget.querySelector('button'),async()=>{
  const [hour,minute]=$('send-time').value.split(':').map(Number);
  const data={enabled:$('enabled').checked,weekday:Number($('weekday').value),hour,minute,timezone:$('timezone').value.trim()};
  showSettings(await api('/api/settings',{method:'PUT',body:JSON.stringify(data)}),true);notice('定时设置已保存。');
});});
$('send-now').addEventListener('click',()=>run($('send-now'),async()=>{const result=await api('/api/send',{method:'POST'});notice({queued:'已加入发送队列，调度器通常在 10 秒内处理。',empty:'没有等待汇总的新单号。',busy:'已有邮件正在处理，请查看发送记录。'}[result.status]);await refresh();}));
$('filter-form').addEventListener('submit',event=>{event.preventDefault();const data=new FormData(event.currentTarget);query=data.get('q');state=data.get('state');page=1;loadParcels().catch(error=>notice(error.message,true));});
$('prev').addEventListener('click',()=>{page--;loadParcels().catch(error=>notice(error.message,true));});
$('next').addEventListener('click',()=>{page++;loadParcels().catch(error=>notice(error.message,true));});
$('logout').addEventListener('click',()=>run($('logout'),async()=>{await api('/api/logout',{method:'POST'});location.href='/login';}));
api('/api/settings').then(s=>showSettings(s,true)).catch(error=>notice(error.message,true));
refresh().catch(error=>notice(error.message,true));
setInterval(()=>{if(!document.hidden)refresh().catch(error=>notice(error.message,true));},10000);

function showMailbox(s, fields = false) {
  const names={not_started:'尚未检查',checking:'正在读取',initialized:'已建立起点，下次读取新邮件',ok:'检查完成',error:'检查失败'};
  $('mailbox-badge').textContent=s.configured ? (s.enabled ? '自动收信已开启' : '自动收信已关闭') : '未配置 IMAP';
  $('mailbox-account').textContent=s.configured ? `邮箱：${s.account} · 文件夹：${s.folder}` : '请在服务器 .env 中配置 IMAP_HOST、IMAP_USER、IMAP_PASSWORD 后重启服务。';
  $('mailbox-state').textContent=s.requested ? '等待调度器检查' : (names[s.status] || s.status);
  $('mailbox-result').textContent=`上次检查：${date(s.last_checked)} · 扫描 ${s.last_scanned} 封 · 新增 ${s.last_imported} 个单号 · 无匹配或跳过 ${s.last_skipped} 封`;
  $('mailbox-error').textContent=s.last_error || '';
  $('mailbox-check').disabled=!s.configured || s.status==='checking' || !!s.requested;
  $('mailbox-enabled').disabled=!s.configured;
  if(fields){$('mailbox-enabled').checked=!!s.enabled;$('mailbox-interval').value=s.interval_minutes;}
}
async function loadMailbox(){showMailbox(await api('/api/mailbox'));}
async function loadOrders(){
  const result=await api('/api/orders'); const box=$('orders'); box.replaceChildren();
  if(!result.items.length){const row=node('tr');const empty=node('td','暂无订单。含明确单号的订单邮件读取后会自动入库。','empty');empty.colSpan=4;row.append(empty);box.append(row);}
  for(const item of result.items){const row=node('tr');row.append(cell(item.platform,item.order_id),cell(item.title,item.status),cell(item.shipments.map(s=>s.tracking_number).join(' / ')),cell(date(item.last_seen)));box.append(row);}
}
$('mailbox-form').addEventListener('submit',event=>{event.preventDefault();run(event.currentTarget.querySelector('button'),async()=>{
  const value={enabled:$('mailbox-enabled').checked,interval_minutes:Number($('mailbox-interval').value)};
  showMailbox(await api('/api/mailbox',{method:'PUT',body:JSON.stringify(value)}),true);notice('收信设置已保存。首次连接只建立起点，请在初始化完成后发送或转发测试邮件。');
});});
$('mailbox-check').addEventListener('click',()=>run($('mailbox-check'),async()=>{await api('/api/mailbox/check',{method:'POST'});notice('已请求检查邮件，通常 10 秒内开始；首次连接只建立起点。');await loadMailbox();}));
api('/api/mailbox').then(s=>showMailbox(s,true)).catch(error=>notice(error.message,true));

let trackingParcelId=null;
function showTrackingSettings(s, fields=false){
  const labels={none:'尚未配置物流服务',kuaidi100:'快递100',gateway:'自有查询网关'};
  $('tracking-service').textContent=s.configured ? `${labels[s.provider] || s.provider} · ${s.enabled ? '自动更新已开启' : '自动更新已关闭'}` : '尚未配置物流服务';
  $('tracking-service-note').textContent=s.configured ? '在单号记录中点击“查看物流”可查看时间线、设置公司代码或手动刷新。邮件已汇总的包裹也会继续更新物流。' : '配置 .env 的物流服务和密钥并重启后启用。当前不会发起外部物流查询；接入说明见 TRACKING.md。';
  $('tracking-enabled').disabled=!s.configured;
  if(fields){$('tracking-enabled').checked=!!s.enabled;$('tracking-interval').value=s.interval_minutes;
    const codes=$('tracking-carriers');codes.replaceChildren();
    for(const value of new Set(Object.values(s.carrier_codes))){const option=node('option');option.value=value;codes.append(option);}
  }
}
async function loadTrackingSettings(){showTrackingSettings(await api('/api/tracking/settings'));}
async function openTracking(id){
  trackingParcelId=id;
  await loadTrackingDetail(true);
  if(!$('tracking-dialog').open)$('tracking-dialog').showModal();
}
async function refreshOpenTracking(){if($('tracking-dialog').open && trackingParcelId!==null)await loadTrackingDetail(false);}
async function loadTrackingDetail(fields){
  const [s,p]=await Promise.all([api(`/api/parcels/${trackingParcelId}/tracking`),api(`/api/parcels/${trackingParcelId}/pickup`)]);
  const sources={manual:'手动填写',email:'通知邮件',tracking:'物流服务'};
  $('pickup-source').textContent=p.source ? `来源：${sources[p.source] || p.source} · 更新：${date(p.updated_at)}${p.manual_lock ? ' · 已锁定手动信息' : ''}` : '尚无取件通知。可手动补充到站信息。';
  if(fields){$('pickup-state').value=p.pickup_state;$('pickup-code').value=p.pickup_code;$('pickup-address').value=p.pickup_address;}
  $('pickup-auto').disabled=!p.manual_lock;
  $('tracking-title').textContent=`物流详情 · ${s.tracking_number}`;
  $('tracking-summary').textContent=`快递：${s.carrier || '未填写'} · 本次查询服务：${s.query_provider}`;
  $('tracking-warning').hidden=s.configured;
  $('tracking-warning').textContent='尚未配置查询服务。可以保存包裹查询设置，配置服务后再刷新。';
  $('tracking-status-title').textContent=s.status_label;
  $('tracking-time').textContent=`上次成功更新：${date(s.last_success)}${s.provider ? ' · 数据来源：'+s.provider : ''}${s.stale ? ' · 当前为较早缓存' : ''}`;
  const busy=s.requested || (s.lease_until && new Date(s.lease_until)>new Date());
  $('tracking-error').textContent=busy ? '已加入队列或正在查询，请稍候。' : s.error;
  $('tracking-refresh').disabled=!s.configured || !!busy;
  $('tracking-phone-note').textContent=`手机号后四位：${s.has_phone_last4 ? '已保存（不会回显）' : '未填写'}。部分快递查询需要此信息；只在刷新时发给所配置的查询服务。`;
  const timeline=$('tracking-timeline');timeline.replaceChildren();
  if(!s.events.length) timeline.append(node('li',s.last_success ? '查询服务暂未返回轨迹明细。' : '尚无轨迹。配置服务后可点击刷新物流。','empty'));
  for(const event of s.events){const entry=node('li');entry.append(node('time',event.time),node('p',event.description));if(event.location)entry.append(node('small',event.location,'muted'));timeline.append(entry);}
  if(fields){$('tracking-carrier').value=s.carrier_code || s.resolved_carrier_code;$('tracking-phone').value='';$('tracking-clear-phone').checked=false;$('tracking-monitored').checked=!!s.monitored;}
}
$('tracking-settings-form').addEventListener('submit',event=>{event.preventDefault();run(event.currentTarget.querySelector('button'),async()=>{
  showTrackingSettings(await api('/api/tracking/settings',{method:'PUT',body:JSON.stringify({enabled:$('tracking-enabled').checked,interval_minutes:Number($('tracking-interval').value)})}),true);
  notice('物流自动更新设置已保存。');
});});
$('tracking-parcel-form').addEventListener('submit',event=>{event.preventDefault();run(event.currentTarget.querySelector('button'),async()=>{
  const values={carrier_code:$('tracking-carrier').value.trim(),monitored:$('tracking-monitored').checked};
  if($('tracking-clear-phone').checked)values.phone_last4='';else if($('tracking-phone').value)values.phone_last4=$('tracking-phone').value;
  await api(`/api/parcels/${trackingParcelId}/tracking`,{method:'PUT',body:JSON.stringify(values)});await loadTrackingDetail(true);notice('包裹查询设置已保存。');
});});
$('tracking-refresh').addEventListener('click',()=>run($('tracking-refresh'),async()=>{
  const result=await api(`/api/parcels/${trackingParcelId}/tracking/refresh`,{method:'POST'});
  notice(result.status==='busy' ? '该包裹已经在查询队列中。' : '已请求更新物流，通常 10 秒内开始查询。');await loadTrackingDetail(false);
}));
$('tracking-close').addEventListener('click',()=>$('tracking-dialog').close());
$('tracking-dialog').addEventListener('close',()=>{trackingParcelId=null;});
api('/api/tracking/settings').then(s=>showTrackingSettings(s,true)).catch(error=>notice(error.message,true));

for(const button of document.querySelectorAll('[data-group]'))button.addEventListener('click',()=>{
  group=button.dataset.group;page=1;loadParcels().catch(error=>notice(error.message,true));
});
$('pickup-form').addEventListener('submit',event=>{event.preventDefault();run(event.currentTarget.querySelector('button'),async()=>{
  await api(`/api/parcels/${trackingParcelId}/pickup`,{method:'PUT',body:JSON.stringify({pickup_state:$('pickup-state').value,pickup_code:$('pickup-code').value.trim(),pickup_address:$('pickup-address').value.trim()})});
  await loadTrackingDetail(true);await loadParcels();notice('取件信息已保存。');
});});
$('pickup-auto').addEventListener('click',()=>run($('pickup-auto'),async()=>{
  await api(`/api/parcels/${trackingParcelId}/pickup/automatic`,{method:'POST'});await loadTrackingDetail(true);notice('已允许后续自动通知更新；已取件记录仍保持完成。');
}));

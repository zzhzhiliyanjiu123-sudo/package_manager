"""Read new order emails over TLS IMAP without marking them read."""
from __future__ import annotations
import imaplib
import base64
import hashlib
import re
import secrets
import ssl
import time
from datetime import timedelta
from email import policy
from email.parser import BytesParser
from email.utils import parseaddr
from html.parser import HTMLParser
from . import core, orders, pickup

TRACKING = re.compile(r'(?:快递单号|快递号码|快递编号|运单号(?:码)?|物流单号|物流编号|配送单号|tracking\s*(?:number|no\.?|#))\s*[:：#号\s]*([A-Za-z0-9][A-Za-z0-9-]{4,79})(?![A-Za-z0-9-])', re.I)
ORDER_ID = re.compile(r'(?:订单编号|订单号码|订单号|order\s*(?:number|no\.?|#))\s*[:：#\s]*([A-Za-z0-9][A-Za-z0-9-]{4,119})(?![A-Za-z0-9-])', re.I)
CARRIERS = ('顺丰', '中通', '圆通', '申通', '韵达', '极兔', '京东物流', '邮政', 'EMS', '德邦', '菜鸟')
PLATFORM_HINTS = (('淘宝/天猫', ('淘宝','天猫','taobao','tmall')), ('京东', ('京东','jd.com')), ('拼多多', ('拼多多','pinduoduo')), ('小红书', ('小红书','xiaohongshu')), ('抖音', ('抖音','douyin')), ('闲鱼', ('闲鱼','goofish')), ('转转', ('转转','zhuanzhuan')))

class VisibleText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.hidden = 0
        self.parts = []
    def handle_starttag(self, tag, attrs):
        if tag in ('script','style'): self.hidden += 1
        elif tag in ('br','p','div','td','tr','li'): self.parts.append(' ')
    def handle_endtag(self, tag):
        if tag in ('script','style') and self.hidden: self.hidden -= 1
        elif tag in ('p','div','td','tr','li'): self.parts.append(' ')
    def handle_data(self, data):
        if not self.hidden: self.parts.append(data)

def extract(raw, allowed_senders=''):
    if len(raw) > 2*1024*1024: raise ValueError('邮件超过 2 MB')
    msg = BytesParser(policy=policy.default).parsebytes(raw)
    sender = parseaddr(str(msg.get('From','')))[1].lower()
    allowlist = [s.strip().lower() for s in allowed_senders.split(',') if s.strip()]
    if allowlist and not any(sender == s if '@' in s else sender.endswith('@'+s) for s in allowlist): return None
    subject = ' '.join(str(msg.get('Subject','')).split())[:500]
    bodies = []
    for part in msg.walk():
        if part.get_content_type() not in ('text/plain','text/html') or part.get_filename() or part.get_content_disposition() == 'attachment': continue
        try: value = part.get_content()
        except (LookupError, UnicodeError): value = (part.get_payload(decode=True) or b'').decode('utf-8', errors='replace')
        if part.get_content_type() == 'text/html':
            parser = VisibleText()
            parser.feed(value)
            value = ''.join(parser.parts)
        bodies.append(value)
    content = ' '.join((subject,*bodies))
    numbers = list(dict.fromkeys(match.upper() for match in TRACKING.findall(content)))
    numbers = [number for number in numbers if any(char.isdigit() for char in number)]
    if not numbers: return None
    hints = (str(msg.get('From',''))+' '+content).lower()
    platform = next((label for label, words in PLATFORM_HINTS if any(word in hints for word in words)), '订单邮件')
    order_ids = list(dict.fromkeys(ORDER_ID.findall(content)))
    order_id = order_ids[0] if len(order_ids) == 1 else ''
    shipments = []
    if len(numbers) > 1000: raise ValueError("单封邮件单号过多")
    for number in numbers:
        position = content.upper().find(number)
        nearby = content[max(0,position-80):position+80]
        carrier = next((name for name in CARRIERS if name.lower() in nearby.lower()), '')
        shipments.append(core.normalize({'tracking_number':number,'carrier':carrier,'platform':platform,'order_id':order_id,'note':subject}))
    result = {'platform':platform,'order_id':order_id,'title':subject,'status':'邮件已包含运单号','shipments':shipments}
    if len(numbers)==1:
        result['pickup'] = pickup.extract_notice(content)
    return result

def init_mailbox(path):
    pickup.init_pickup(path)
    with core.database(path) as con:
        con.executescript('''
            CREATE TABLE IF NOT EXISTS mailbox_settings (
                id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 0,
                interval_minutes INTEGER NOT NULL DEFAULT 5, next_check TEXT NOT NULL DEFAULT '',
                requested INTEGER NOT NULL DEFAULT 0, uid_validity TEXT NOT NULL DEFAULT '',
                last_uid INTEGER NOT NULL DEFAULT 0, lease_until TEXT, claim_token TEXT,
                last_checked TEXT NOT NULL DEFAULT '', last_success TEXT NOT NULL DEFAULT '',
                last_error TEXT NOT NULL DEFAULT '', last_scanned INTEGER NOT NULL DEFAULT 0,
                last_imported INTEGER NOT NULL DEFAULT 0, last_skipped INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'not_started'
            );
            INSERT OR IGNORE INTO mailbox_settings(id) VALUES(1);
        ''')

def folder_argument(value):
    if not value or any(ord(c)<32 for c in value):
        raise ValueError("IMAP 文件夹名称不正确")
    result, non_ascii = [], []
    def flush():
        if non_ascii:
            encoded = base64.b64encode(''.join(non_ascii).encode('utf-16-be')).decode('ascii').rstrip('=').replace('/', ',')
            result.append('&'+encoded+'-')
            non_ascii.clear()
    for char in value:
        if 32 <= ord(char) <= 126:
            flush()
            result.append('&-' if char == '&' else char)
        else:
            non_ascii.append(char)
    flush()
    encoded = ''.join(result)
    return '"' + encoded.replace(chr(92), chr(92)*2).replace('"', chr(92)+'"') + '"'


def configured(cfg):
    return all(cfg.get(key) for key in ('IMAP_HOST','IMAP_USER','IMAP_PASSWORD'))

def state(path, cfg):
    with core.database(path) as con:
        result = dict(con.execute('SELECT * FROM mailbox_settings WHERE id=1').fetchone())
    result.pop('claim_token',None)
    result.pop('uid_validity',None)
    result.update(configured=configured(cfg),folder=cfg.get('IMAP_FOLDER','INBOX'),account=cfg.get('IMAP_USER',''))
    return result

def save(path, enabled, interval):
    if type(enabled) is not bool or type(interval) is not int or not 1 <= interval <= 1440:
        raise ValueError('邮件开关需为布尔值，检查间隔为 1–1440 分钟的整数')
    with core.database(path) as con:
        con.execute('UPDATE mailbox_settings SET enabled=?,interval_minutes=?,next_check=? WHERE id=1',(int(enabled),interval,core.stamp()))

def request_check(path):
    with core.database(path) as con:
        con.execute('UPDATE mailbox_settings SET requested=1,next_check=? WHERE id=1',(core.stamp(),))

def require_ok(result):
    if result[0] != 'OK': raise RuntimeError('IMAP 请求失败')
    return result[1]

def checkpoint(path, claim, validity, uid):
    with core.database(path) as con:
        changed = con.execute('UPDATE mailbox_settings SET uid_validity=?,last_uid=? WHERE id=1 AND claim_token=?',(validity,uid,claim)).rowcount
        if not changed: raise RuntimeError('收信任务租约已失效')

def sync_tick(path, cfg, factory=imaplib.IMAP4_SSL, now=None):
    current = now or core.now_utc()
    instant = core.stamp(current)
    claim = secrets.token_hex(16)
    with core.database(path) as con:
        con.execute('BEGIN IMMEDIATE')
        setting = con.execute('SELECT * FROM mailbox_settings WHERE id=1').fetchone()
        recovering = setting['status'] == 'checking' and setting['lease_until'] and setting['lease_until'] <= instant
        if (not recovering and not setting['requested'] and (not setting['enabled'] or setting['next_check'] > instant)) or (setting['lease_until'] and setting['lease_until'] > instant):
            con.commit()
            return 'idle'
        con.execute("UPDATE mailbox_settings SET requested=0,status='checking',claim_token=?,lease_until=?,last_checked=? WHERE id=1",(claim,core.stamp(current+timedelta(minutes=15)),instant))
        con.commit()
    client = None
    scanned = inserted = skipped = 0
    outcome, error = 'ok', ''
    try:
        if not configured(cfg): raise ValueError('尚未配置 IMAP')
        client = factory(cfg['IMAP_HOST'],int(cfg.get('IMAP_PORT','993')),timeout=20,ssl_context=ssl.create_default_context())
        require_ok(client.login(cfg['IMAP_USER'],cfg['IMAP_PASSWORD']))
        require_ok(client.select(folder_argument(cfg.get('IMAP_FOLDER','INBOX')),readonly=True))
        validity = client.response('UIDVALIDITY')[1]
        if not validity or not validity[0]: raise RuntimeError('IMAP 未返回 UIDVALIDITY')
        identity = '\n'.join((cfg['IMAP_HOST'], str(cfg.get('IMAP_PORT','993')), cfg['IMAP_USER'], cfg.get('IMAP_FOLDER','INBOX')))
        validity = hashlib.sha256(identity.encode()).hexdigest() + ':' + validity[0].decode('ascii')
        if setting['uid_validity'] != validity:
            all_uids = require_ok(client.uid('search',None,'ALL'))[0] or b''
            last_uid = max((int(uid) for uid in all_uids.split()),default=0)
            checkpoint(path,claim,validity,last_uid)
            outcome = 'initialized'
        else:
            last_uid = setting['last_uid']
            data = require_ok(client.uid('search',None,f'UID {last_uid+1}:*'))[0] or b''
            uids = sorted({int(uid) for uid in data.split() if int(uid) > last_uid})[:25]
            started = time.monotonic()
            for uid in uids:
                if time.monotonic()-started > 45: break
                metadata = require_ok(client.uid('fetch',str(uid),'(RFC822.SIZE)'))
                size = re.search(rb'RFC822.SIZE\s+(\d+)',b' '.join(part for part in metadata if isinstance(part,bytes)))
                if not size: raise RuntimeError('无法读取邮件大小')
                if int(size.group(1)) > 2*1024*1024:
                    skipped += 1
                else:
                    parts = require_ok(client.uid('fetch',str(uid),'(BODY.PEEK[])'))
                    raw = next((part[1] for part in parts if isinstance(part,tuple)),None)
                    if raw is None: raise RuntimeError('无法读取邮件正文')
                    try:
                        record = extract(raw,cfg.get('IMAP_ALLOWED_SENDERS',''))
                    except (ValueError, TypeError, LookupError):
                        record = None
                    if record:
                        if record['order_id'] and len(record['shipments']) <= 20:
                            inserted += orders.ingest_orders(path,[record])['parcels_inserted']
                        else:
                            inserted += core.add_parcels(path,record['shipments'])['inserted']
                        if record.get('pickup') and len(record['shipments'])==1:
                            pickup.automatic(path,record['shipments'][0]['tracking_number'],record['pickup'],'email')
                    else: skipped += 1
                scanned += 1
                checkpoint(path,claim,validity,uid)
    except Exception as exc:
        outcome = 'error'
        error = f'{type(exc).__name__}：读取失败，请检查 IMAP 地址、授权码、文件夹和网络'
    finally:
        if client:
            try: client.logout()
            except Exception: pass
    with core.database(path) as con:
        con.execute('''UPDATE mailbox_settings SET status=?,last_error=?,last_success=CASE WHEN ?='' THEN ? ELSE last_success END,
            next_check=?,last_scanned=?,last_imported=?,last_skipped=?,lease_until=NULL,claim_token=NULL WHERE id=1 AND claim_token=?''',
            (outcome,error,error,instant,core.stamp(current+timedelta(minutes=setting['interval_minutes'])),scanned,inserted,skipped,claim))
    return outcome

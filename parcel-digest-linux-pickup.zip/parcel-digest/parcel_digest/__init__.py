"""Personal parcel inbox and weekly email digest."""

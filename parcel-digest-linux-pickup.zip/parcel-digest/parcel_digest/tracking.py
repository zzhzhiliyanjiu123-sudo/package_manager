"""Cached logistics queries, with optional provider credentials and independent scheduling."""
from __future__ import annotations
import hashlib
import json
import re
import secrets
from datetime import datetime, timedelta
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler
from . import core, pickup

STATUS_NAMES = {'unknown':'尚无物流状态','not_found':'暂无轨迹','collected':'已揽收','in_transit':'运输中','out_for_delivery':'派送中','ready_for_pickup':'到站待取件','picked_up':'已取件','delivered':'已签收','exception':'物流异常','returning':'退回中','returned':'已退回'}
TERMINAL = ('delivered','returned','picked_up')
CARRIER_CODES = {'顺丰':'shunfeng','顺丰速运':'shunfeng','中通':'zhongtong','中通快递':'zhongtong','圆通':'yuantong','圆通速递':'yuantong','申通':'shentong','申通快递':'shentong','韵达':'yunda','韵达快递':'yunda','极兔':'jtexpress','极兔速递':'jtexpress','京东':'jd','京东物流':'jd','邮政':'youzhengguonei','邮政快递包裹':'youzhengguonei','EMS':'ems','德邦':'debangwuliu','德邦快递':'debangwuliu'}

class TrackingError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise TrackingError('redirect','物流接口发生重定向，请核对配置地址')

def configured(cfg):
    provider = cfg.get('TRACKING_PROVIDER','none')
    if provider == 'kuaidi100': return bool(cfg.get('KUAIDI100_CUSTOMER') and cfg.get('KUAIDI100_KEY'))
    if provider == 'gateway':
        return bool(cfg.get('TRACKING_GATEWAY_URL') and cfg.get('TRACKING_GATEWAY_TOKEN'))
    return False

def init_tracking(path):
    pickup.init_pickup(path)
    with core.database(path) as con:
        con.executescript('''
            CREATE TABLE IF NOT EXISTS tracking_settings (
                id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 0,
                interval_minutes INTEGER NOT NULL DEFAULT 30
            );
            INSERT OR IGNORE INTO tracking_settings(id) VALUES(1);
            CREATE TABLE IF NOT EXISTS parcel_tracking (
                parcel_id INTEGER PRIMARY KEY REFERENCES parcels(id),
                carrier_code TEXT NOT NULL DEFAULT '', phone_last4 TEXT NOT NULL DEFAULT '',
                monitored INTEGER NOT NULL DEFAULT 1, requested INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'unknown', events_json TEXT NOT NULL DEFAULT '[]',
                last_attempt TEXT NOT NULL DEFAULT '', last_success TEXT NOT NULL DEFAULT '',
                next_refresh TEXT NOT NULL DEFAULT '', error TEXT NOT NULL DEFAULT '',
                error_code TEXT NOT NULL DEFAULT '', failures INTEGER NOT NULL DEFAULT 0,
                lease_until TEXT, claim_token TEXT, provider TEXT NOT NULL DEFAULT ''
            );
        ''')

def ensure_rows(con):
    con.execute('INSERT OR IGNORE INTO parcel_tracking(parcel_id) SELECT id FROM parcels')

def settings(path, cfg):
    with core.database(path) as con:
        result = dict(con.execute('SELECT * FROM tracking_settings WHERE id=1').fetchone())
    result.update(configured=configured(cfg),provider=cfg.get('TRACKING_PROVIDER','none'),status_names=STATUS_NAMES,
                  carrier_codes=CARRIER_CODES)
    return result

def save_settings(path, enabled, interval):
    if type(enabled) is not bool or type(interval) is not int or not 5 <= interval <= 1440:
        raise ValueError('物流开关需为布尔值，自动查询间隔为 5–1440 分钟的整数')
    with core.database(path) as con:
        con.execute('UPDATE tracking_settings SET enabled=?,interval_minutes=? WHERE id=1',(int(enabled),interval))
        con.execute("UPDATE parcel_tracking SET next_refresh='' WHERE lease_until IS NULL")

def code_for(parcel, cfg):
    if parcel['carrier_code']: return parcel['carrier_code']
    if cfg.get('TRACKING_PROVIDER') == 'kuaidi100':
        return CARRIER_CODES.get(parcel['carrier'],'')
    return ''

def detail(path, parcel_id, cfg):
    with core.database(path) as con:
        ensure_rows(con)
        row=con.execute('SELECT p.tracking_number,p.carrier,t.* FROM parcel_tracking t JOIN parcels p ON p.id=t.parcel_id WHERE p.id=?',(parcel_id,)).fetchone()
    if not row: raise ValueError('单号记录不存在')
    result=dict(row)
    result.pop('claim_token',None)
    result.pop('phone_last4',None)
    result['has_phone_last4']=bool(row['phone_last4'])
    result['resolved_carrier_code']=code_for(row,cfg)
    result['events']=json.loads(result.pop('events_json'))
    result['status_label']=STATUS_NAMES.get(result['status'],STATUS_NAMES['unknown'])
    result['configured']=configured(cfg)
    result['query_provider']=cfg.get('TRACKING_PROVIDER','none')
    result['stale']=bool(result['last_success'] and (result['error'] or (result['status'] not in TERMINAL and result['next_refresh'] and result['next_refresh'] <= core.stamp())))
    return result

def save_parcel(path, parcel_id, values):
    code=values.get('carrier_code','')
    monitored=values.get('monitored')
    phone=values.get('phone_last4')  # Omitted keeps saved value; empty explicitly clears it.
    if not isinstance(code,str) or (code and not re.fullmatch(r'[A-Za-z0-9_-]{1,64}',code)) or type(monitored) is not bool:
        raise ValueError('请填写有效快递公司代码和布尔型监测开关')
    if phone is not None and (not isinstance(phone,str) or (phone and not re.fullmatch(r'[0-9]{4}',phone))):
        raise ValueError('手机号后四位只能为 4 位数字，留空可清除')
    with core.database(path) as con:
        con.execute('BEGIN IMMEDIATE')
        ensure_rows(con)
        old=con.execute('SELECT * FROM parcel_tracking WHERE parcel_id=?',(parcel_id,)).fetchone()
        if not old: raise ValueError('单号记录不存在')
        if old['lease_until'] and old['lease_until'] > core.stamp(): raise ValueError('物流查询进行中，请稍后修改')
        changed = code != old['carrier_code']
        con.execute('''UPDATE parcel_tracking SET carrier_code=?,phone_last4=?,monitored=?,next_refresh='',
            requested=CASE WHEN ?=0 THEN 0 ELSE requested END,error='',error_code='',failures=0,lease_until=NULL,claim_token=NULL WHERE parcel_id=?''',
            (code, old['phone_last4'] if phone is None else phone, int(monitored), int(monitored), parcel_id))
        if changed:
            con.execute("UPDATE parcel_tracking SET status='unknown',events_json='[]',last_success='',provider='' WHERE parcel_id=?",(parcel_id,))
        con.commit()

def request_refresh(path, parcel_id, cfg):
    if not configured(cfg): raise ValueError('尚未配置物流查询服务，请先在 .env 配置并重启')
    with core.database(path) as con:
        con.execute('BEGIN IMMEDIATE')
        ensure_rows(con)
        row=con.execute('SELECT p.carrier,t.* FROM parcel_tracking t JOIN parcels p ON p.id=t.parcel_id WHERE parcel_id=?',(parcel_id,)).fetchone()
        if not row: raise ValueError('单号记录不存在')
        if row['requested'] or (row['lease_until'] and row['lease_until']>core.stamp()):
            con.commit()
            return 'busy'
        if not code_for(row,cfg): raise ValueError('请先在物流详情中填写快递公司代码')
        if row['last_attempt'] and core.now_utc()-datetime.fromisoformat(row['last_attempt']) < timedelta(seconds=60):
            raise ValueError('该单号刚刚查询过，请至少间隔 60 秒再刷新')
        con.execute("UPDATE parcel_tracking SET requested=1,next_refresh='' WHERE parcel_id=?",(parcel_id,))
        con.commit()
    return 'queued'

def normalize_response(payload, number):
    if not isinstance(payload,dict) or not isinstance(payload.get('tracking_number'),str) or payload['tracking_number'].upper() != number.upper():
        raise TrackingError('mismatch','物流服务返回的单号不匹配')
    status=payload.get('status','unknown')
    if not isinstance(status,str) or status not in STATUS_NAMES: raise TrackingError('format','物流服务返回了未知的状态格式')
    events=payload.get('events',[])
    if not isinstance(events,list) or len(events)>1000: raise TrackingError('format','物流轨迹格式不正确或记录过多')
    cleaned=[]
    for item in events:
        if not isinstance(item,dict): raise TrackingError('format','物流轨迹格式不正确')
        event={}
        for field,limit in (('time',80),('description',2000),('location',200)):
            value=item.get(field,'')
            if not isinstance(value,str) or len(value)>limit: raise TrackingError('format','物流轨迹字段格式不正确')
            event[field]=value.strip()
        if not event['time'] or not event['description']: raise TrackingError('format','物流轨迹缺少时间或描述')
        if event not in cleaned: cleaned.append(event)
    # Gateways must provide newest-first. The native adapter also provides that order.
    notice = pickup.extract_notice(cleaned[0]['description']) if cleaned else {'pickup_code':'','pickup_address':'','pickup_state':''}
    if 'pickup' in payload:
        if not isinstance(payload['pickup'],dict): raise TrackingError('format','取件信息格式不正确')
        structured = dict(payload['pickup'])
        if 'pickup_state' not in structured:
            structured['pickup_state'] = 'ready' if structured.get('pickup_code') or status=='ready_for_pickup' else ''
        try: structured = pickup.validate(structured)
        except ValueError as exc: raise TrackingError('format','取件信息格式不正确') from exc
        notice = {key: structured[key] or notice[key] for key in notice}
    if status in ('ready_for_pickup','picked_up'):
        notice['pickup_state'] = 'ready' if status=='ready_for_pickup' else 'collected'
    elif status=='returned':
        notice = {'pickup_code':'','pickup_address':'','pickup_state':''}
    elif notice['pickup_state']=='ready':
        status='ready_for_pickup'
    elif notice['pickup_state']=='collected':
        status='picked_up'
    return {'status':status,'events':cleaned,'pickup':notice}

def post_json(url, data, headers=None):
    parsed=urlsplit(url)
    if parsed.scheme!='https' or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
        raise TrackingError('configuration','物流接口必须是无账号信息的 HTTPS 地址')
    request=Request(url,data=data,headers=headers or {},method='POST')
    with build_opener(NoRedirect()).open(request,timeout=20) as response:
        raw=response.read(2*1024*1024+1)
        if len(raw)>2*1024*1024: raise TrackingError('format','物流接口响应超过 2 MB')
    try: return json.loads(raw)
    except (ValueError,UnicodeError) as exc: raise TrackingError('format','物流接口未返回合法 JSON') from exc

def query_provider(parcel, cfg, transport=post_json):
    provider=cfg.get('TRACKING_PROVIDER','none')
    number=parcel['tracking_number']
    code=code_for(parcel,cfg)
    if not code: raise TrackingError('needs_carrier','请在物流详情中填写快递公司代码')
    if provider=='kuaidi100':
        param={'com':code,'num':number,'resultv2':'4','order':'desc'}
        if parcel['phone_last4']: param['phone']=parcel['phone_last4']
        encoded=json.dumps(param,ensure_ascii=False,separators=(',',':'))
        sign=hashlib.md5((encoded+cfg['KUAIDI100_KEY']+cfg['KUAIDI100_CUSTOMER']).encode()).hexdigest().upper()
        body=urlencode({'customer':cfg['KUAIDI100_CUSTOMER'],'sign':sign,'param':encoded}).encode()
        raw=transport('https://poll.kuaidi100.com/poll/query.do',body,{'Content-Type':'application/x-www-form-urlencoded'})
        if not isinstance(raw,dict) or str(raw.get('status'))!='200':
            raise TrackingError('service_rejected','物流服务未返回有效结果，请核对接口权限、公司代码和手机号后四位')
        states={'0':'in_transit','1':'collected','2':'exception','3':'delivered','4':'returning','5':'out_for_delivery','6':'returned','7':'in_transit'}
        records=raw.get('data',[])
        if not isinstance(records,list) or not all(isinstance(event,dict) for event in records): raise TrackingError('format','物流服务轨迹格式不正确')
        payload={'tracking_number':raw.get('nu',''),'status':states.get(str(raw.get('state','')),'unknown'),
                 'events':[{'time':event.get('ftime') or event.get('time',''),'description':event.get('context',''),'location':event.get('areaName') or ''} for event in records]}
    elif provider=='gateway':
        body=json.dumps({'tracking_number':number,'carrier_code':code,'phone_last4':parcel['phone_last4']},ensure_ascii=False).encode()
        payload=transport(cfg['TRACKING_GATEWAY_URL'],body,{'Content-Type':'application/json','Authorization':'Bearer '+cfg['TRACKING_GATEWAY_TOKEN']})
    else: raise TrackingError('configuration','尚未配置物流服务')
    return normalize_response(payload,number)

def sync_tick(path,cfg,query=query_provider,now=None):
    if not configured(cfg): return 'idle'
    current=now or core.now_utc()
    instant=core.stamp(current)
    claim=secrets.token_hex(16)
    with core.database(path) as con:
        con.execute('BEGIN IMMEDIATE')
        ensure_rows(con)
        options=con.execute('SELECT * FROM tracking_settings WHERE id=1').fetchone()
        row=con.execute('''SELECT p.tracking_number,p.carrier,t.* FROM parcel_tracking t JOIN parcels p ON p.id=t.parcel_id
            WHERE (t.lease_until IS NULL OR t.lease_until<=?) AND (t.requested=1 OR (t.lease_until IS NOT NULL AND t.lease_until<=?)
            OR (?=1 AND t.monitored=1 AND p.state!='excluded' AND t.status NOT IN ('delivered','returned','picked_up') AND NOT EXISTS (SELECT 1 FROM parcel_pickup k WHERE k.parcel_id=p.id AND k.pickup_state='collected') AND t.next_refresh<=?))
            ORDER BY t.requested DESC,t.next_refresh,t.parcel_id LIMIT 1''',(instant,instant,options['enabled'],instant)).fetchone()
        if not row:
            con.commit()
            return 'idle'
        con.execute('UPDATE parcel_tracking SET requested=0,last_attempt=?,lease_until=?,claim_token=? WHERE parcel_id=?',
                    (instant,core.stamp(current+timedelta(minutes=5)),claim,row['parcel_id']))
        con.commit()
    error=error_code=''
    result=None
    try:
        result=normalize_response({'tracking_number':row['tracking_number'],**query(dict(row),cfg)},row['tracking_number'])
    except TrackingError as exc:
        error,error_code=str(exc),exc.code
    except Exception:
        error,error_code='物流查询失败，请检查查询服务配置、额度和网络；保留上次结果','query_failed'
    delay=options['interval_minutes'] if not error else min(1440,max(options['interval_minutes'],5*2**min(row['failures'],8)))
    with core.database(path) as con:
        con.execute('BEGIN IMMEDIATE')
        if result is not None and not error:
            changed = con.execute('''UPDATE parcel_tracking SET status=?,events_json=?,last_success=?,next_refresh=?,error='',error_code='',
                failures=0,provider=?,lease_until=NULL,claim_token=NULL WHERE parcel_id=? AND claim_token=?''',
                (result['status'],json.dumps(result['events'],ensure_ascii=False),instant,core.stamp(current+timedelta(minutes=delay)),cfg.get('TRACKING_PROVIDER','none'),row['parcel_id'],claim)).rowcount
            if changed and result.get('pickup'):
                pickup.apply(con,row['parcel_id'],result['pickup'],'tracking')
        else:
            con.execute('''UPDATE parcel_tracking SET next_refresh=?,error=?,error_code=?,failures=failures+1,
                lease_until=NULL,claim_token=NULL WHERE parcel_id=? AND claim_token=?''',
                (core.stamp(current+timedelta(minutes=delay)),error,error_code,row['parcel_id'],claim))
        con.commit()
    return 'error' if error else 'updated'

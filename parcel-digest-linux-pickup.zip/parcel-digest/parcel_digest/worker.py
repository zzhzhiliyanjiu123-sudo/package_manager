"""Run separately: python -m parcel_digest.worker."""
import logging
import signal
import threading
from . import core, orders, mailbox, tracking, pickup

def main():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    cfg = core.configuration()
    path = cfg['DATABASE_PATH']
    core.init_db(path)
    orders.init_orders(path)
    mailbox.init_mailbox(path)
    tracking.init_tracking(path)
    pickup.init_pickup(path)
    stop = threading.Event()
    for sig in (signal.SIGINT,signal.SIGTERM):
        signal.signal(sig, lambda *_: stop.set())
    def mail_loop():
        while not stop.is_set():
            try:
                result = mailbox.sync_tick(path,cfg)
                if result != 'idle': logging.info('收信任务状态：%s',result)
            except Exception:
                logging.error('收信调度异常，将在下一轮重试')
            stop.wait(10)
    thread = threading.Thread(target=mail_loop,name='imap-reader',daemon=True)
    thread.start()
    def tracking_loop():
        while not stop.is_set():
            try:
                result = tracking.sync_tick(path,cfg)
                if result != 'idle': logging.info('物流查询状态：%s',result)
            except Exception:
                logging.error('物流调度异常，将在下一轮重试')
            # Limit to at most six serial queries per minute per scheduler process.
            stop.wait(10)
    logistics = threading.Thread(target=tracking_loop,name='logistics-reader',daemon=True)
    logistics.start()
    logging.info('邮件、IMAP 和物流调度器启动')
    while not stop.is_set():
        try:
            result = core.scheduler_tick(path,cfg)
            if result != 'idle': logging.info('发送任务状态：%s',result)
        except Exception:
            logging.error('邮件调度异常，将在下一轮重试')
        stop.wait(10)
    thread.join(timeout=3)
    logistics.join(timeout=3)

if __name__ == '__main__':
    main()

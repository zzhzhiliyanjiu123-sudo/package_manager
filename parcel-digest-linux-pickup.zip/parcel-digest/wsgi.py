from parcel_digest.web import create_app

app = create_app()
